window.FSA_QUESTIONS = [
  {
    "id": "q201",
    "subject": "FSA",
    "topic": "Introduction to Financial Statement Analysis",
    "subtopic": "Analysis framework",
    "difficulty": "BRUTAL",
    "stem": "An analyst is asked whether a manufacturer can safely add debt. She immediately calculates the current ratio from the latest annual report and recommends approval because it exceeds the industry median. She has not defined the credit question, reviewed footnotes, examined cash-flow seasonality, or investigated a major acquisition completed after year-end. Which change would most improve the analysis process?",
    "options": [
      "Replace the current ratio with return on equity because profitability ratios dominate liquidity ratios in credit analysis.",
      "Define the decision objective first, collect relevant filings and supplementary information, process and interpret the data, then form and monitor a conclusion.",
      "Use only audited statement figures because supplementary information and post-balance-sheet events are less reliable than the annual report."
    ],
    "correct": 1,
    "explanation": "Financial statement analysis is a process, not a ratio lookup. The analyst should first articulate the purpose and context, then gather relevant data—including notes, management commentary and subsequent information—process the data, interpret it, communicate a conclusion and follow up. A different single ratio does not repair the sequencing problem, and audited statements are not the only relevant source.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/introduction-financial-statement-analysis"
  },
  {
    "id": "q202",
    "subject": "FSA",
    "topic": "Introduction to Financial Statement Analysis",
    "subtopic": "Audit and management commentary",
    "difficulty": "HARD",
    "stem": "A company reports record operating profit. Its auditor issues an unmodified opinion, while management commentary notes that the largest customer, responsible for 28% of sales, has notified the company that it will not renew its contract. An analyst concludes that the audit opinion proves next year's profit is likely sustainable. The analyst's conclusion is least defensible because:",
    "options": [
      "customer concentration matters only to credit investors, not to equity or earnings analysis.",
      "an unmodified audit opinion addresses whether the statements are fairly presented under the reporting framework; it does not validate management's future earnings outlook.",
      "management commentary is always unaudited and therefore must be ignored in valuation work."
    ],
    "correct": 1,
    "explanation": "The audit opinion provides assurance about the financial statements, not a guarantee of future economics. The disclosed loss of a large customer is forward-looking information that can materially affect forecasts. Management commentary may be unaudited, but that does not make it irrelevant; analysts routinely use it with appropriate skepticism.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/introduction-financial-statement-analysis"
  },
  {
    "id": "q203",
    "subject": "FSA",
    "topic": "Introduction to Financial Statement Analysis",
    "subtopic": "Alternative reporting systems",
    "difficulty": "BRUTAL",
    "stem": "Two economically similar firms report under different accounting frameworks. Firm A recognizes an item on the balance sheet that Firm B discloses only in the notes under its applicable framework. A junior analyst compares total assets and concludes A has invested more capital. What is the most appropriate next step?",
    "options": [
      "Understand the recognition and measurement differences and, when feasible, adjust the statements to improve comparability before interpreting the asset difference.",
      "Accept reported total assets as fully comparable because both firms comply with legitimate accounting standards.",
      "Exclude the disclosed item from both companies because only recognized items can be used in financial analysis."
    ],
    "correct": 0,
    "explanation": "Compliance with different reporting frameworks does not create automatic comparability. Analysts must understand how recognition, measurement and disclosure differences affect reported numbers and adjust when a reasonable comparable basis is possible. Ignoring disclosures can throw away economically relevant information; blindly accepting totals can confuse accounting form with economic investment.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/introduction-financial-statement-analysis"
  },
  {
    "id": "q204",
    "subject": "FSA",
    "topic": "Introduction to Financial Statement Analysis",
    "subtopic": "Information sources",
    "difficulty": "BRUTAL",
    "stem": "An analyst reviewing a retailer sees flat annual revenue but a sharp rise in inventory. The annual report contains only aggregated inventory data. A regulator filing released two weeks later discloses that most of the increase is obsolete seasonal merchandise, while a management presentation describes it as inventory built for growth. Which source treatment is most appropriate?",
    "options": [
      "Incorporate both sources, giving greater analytical weight to the detailed regulatory disclosure and reconciling it against management's narrative.",
      "Use only the annual report because mixing information sources violates comparability.",
      "Use the management presentation because it is more recent and therefore supersedes the filing."
    ],
    "correct": 0,
    "explanation": "FSA explicitly requires analysts to use sources beyond annual and interim statements. The detailed regulatory disclosure is directly relevant to inventory quality and should be reconciled with management's more promotional explanation. Recency alone does not determine credibility, and restricting analysis to the annual report would ignore decision-useful information.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/introduction-financial-statement-analysis"
  },
  {
    "id": "q205",
    "subject": "FSA",
    "topic": "Introduction to Financial Statement Analysis",
    "subtopic": "Role-specific analysis",
    "difficulty": "EXTREME",
    "stem": "A company has strong net income growth, weak operating cash flow, and a large debt maturity in 14 months. One analyst is evaluating a five-year bond; another is valuing the common shares. Which statement best reflects the role of financial statement analysis?",
    "options": [
      "The bond analyst should rely on the balance sheet only, while the equity analyst should rely on the income statement only.",
      "Both analysts should study the same statements, but the bond analyst will emphasize liquidity and debt-servicing capacity while the equity analyst will emphasize sustainable profitability and per-share value.",
      "Because the statements are identical, the economically correct analytical emphasis must also be identical for both investors."
    ],
    "correct": 1,
    "explanation": "Financial statement analysis is purpose-dependent. Credit analysis stresses the probability and timing of contractual payments, so cash generation, liquidity and solvency are central. Equity analysis also uses those facts but focuses on residual profitability, growth and value per share. The same underlying reports can support different decision questions without implying selective accounting.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/introduction-financial-statement-analysis"
  },
  {
    "id": "q206",
    "subject": "FSA",
    "topic": "Analyzing Income Statements",
    "subtopic": "Revenue recognition",
    "difficulty": "BRUTAL",
    "stem": "A software vendor signs a three-year contract on 1 January for a non-refundable upfront payment of $360,000. The customer receives continuous access to the same hosted service over the three years; no distinct product is delivered at signing. Management wants to recognize the full payment immediately because cash has been collected. For analytical purposes, the most defensible view is that revenue should generally be recognized:",
    "options": [
      "only at the end of year three, because the contract is not complete before then.",
      "as the service obligation is satisfied over the access period, rather than simply when cash is collected.",
      "immediately, because non-refundable cash collection is sufficient evidence that revenue has been earned."
    ],
    "correct": 1,
    "explanation": "Revenue recognition follows performance, not merely cash timing. Here the economic service is provided continuously over three years, so recognizing the entire upfront receipt on day one would accelerate revenue and distort margins. Waiting until the final day would be equally inconsistent with service already delivered during the contract.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-income-statements"
  },
  {
    "id": "q207",
    "subject": "FSA",
    "topic": "Analyzing Income Statements",
    "subtopic": "Capitalized versus expensed costs",
    "difficulty": "BRUTAL",
    "stem": "Two identical firms incur the same $12 million cost this year. Firm X expenses it immediately; Firm Y capitalizes the cost as an asset and will amortize it in future periods. Ignore taxes and assume the capitalization is permitted. Relative to X in the current year, Y will most likely report:",
    "options": [
      "the same net income because capitalization changes only the balance sheet classification.",
      "higher net income and higher assets, with the current-period expense shifted partly into future periods.",
      "lower net income and lower assets because capitalization increases future amortization."
    ],
    "correct": 1,
    "explanation": "Capitalization defers recognition of cost. In the current period, Firm Y records an asset rather than the full expense, so current income and assets are higher than under immediate expensing. Future periods then bear amortization or depreciation. The key trap is confusing lifetime total expense with the timing of expense recognition.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-income-statements"
  },
  {
    "id": "q208",
    "subject": "FSA",
    "topic": "Analyzing Income Statements",
    "subtopic": "Capitalization cash-flow effect",
    "difficulty": "EXTREME",
    "stem": "Two otherwise identical companies spend $8 million cash on the same project. Company E expenses the cost; Company C capitalizes it. Assume both treatments are permitted and the capitalized outlay is classified as investing cash flow. Which current-year comparison is most accurate?",
    "options": [
      "C and E report identical CFO because both paid the same amount of cash.",
      "C reports higher CFO and lower CFI than E, while total cash flow is unchanged by the accounting classification.",
      "C reports higher CFO and higher total cash flow because capitalization creates an asset."
    ],
    "correct": 1,
    "explanation": "The economic cash outflow is the same, so total change in cash does not differ. But classification does: immediate expensing generally places the cash outflow in operations, whereas a capitalized long-lived investment is an investing outflow. Thus C has higher CFO and more negative CFI. This is why analysts should not equate higher CFO caused by capitalization with superior cash economics.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-income-statements"
  },
  {
    "id": "q209",
    "subject": "FSA",
    "topic": "Analyzing Income Statements",
    "subtopic": "Non-recurring items",
    "difficulty": "BRUTAL",
    "stem": "A company reports operating income of $90 million, including a $25 million gain from selling its only headquarters building and a $10 million restructuring charge related to closing an obsolete plant. Management labels both items “non-recurring.” For forecasting sustainable operating performance, the analyst should most appropriately:",
    "options": [
      "assess each item's economic recurrence separately rather than mechanically exclude everything management labels non-recurring.",
      "exclude both items automatically because management's non-recurring label determines normalized earnings.",
      "retain both items automatically because they appear in reported operating income."
    ],
    "correct": 0,
    "explanation": "Normalization is analytical, not label-driven. A one-time asset-sale gain may have little forecasting relevance, while restructuring charges can recur in firms that repeatedly reorganize. The analyst should examine nature, frequency and business context. Neither reported classification nor management's label alone establishes whether an item is sustainable.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-income-statements"
  },
  {
    "id": "q210",
    "subject": "FSA",
    "topic": "Analyzing Income Statements",
    "subtopic": "Accounting policy change",
    "difficulty": "HARD",
    "stem": "A firm changes an accounting policy and restates prior periods as required, making historical margins lower but more comparable to the current policy. An analyst evaluating a five-year margin trend should most appropriately:",
    "options": [
      "use the restated historical figures when they provide a consistent basis and investigate the economic reason for the policy change.",
      "discard all pre-change history because no accounting-policy change can be made comparable across time.",
      "combine the originally reported prior figures with the current year because those were the numbers investors actually saw at the time."
    ],
    "correct": 0,
    "explanation": "When prior periods are restated on a consistent basis, those figures generally improve trend comparability. The analyst should still understand why the policy changed and whether incentives are involved. Mixing old-policy data with new-policy data creates an artificial trend; discarding usable restated history wastes relevant information.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-income-statements"
  },
  {
    "id": "q211",
    "subject": "FSA",
    "topic": "Analyzing Income Statements",
    "subtopic": "Basic EPS",
    "difficulty": "BRUTAL",
    "stem": "A company reports net income of $48 million. It has $3 million of preferred dividends. Common shares were 20 million from 1 January through 30 June and 26 million from 1 July through 31 December after a cash share issue. What is basic EPS?",
    "options": [
      "$1.73",
      "$2.25",
      "$1.96"
    ],
    "correct": 2,
    "explanation": "Income available to common shareholders is $48m − $3m = $45m. Weighted-average common shares are 20m × 6/12 + 26m × 6/12 = 23m. Basic EPS = $45m / 23m = about $1.96. Using ending shares gives about $1.73; using beginning shares gives $2.25.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-income-statements"
  },
  {
    "id": "q212",
    "subject": "FSA",
    "topic": "Analyzing Income Statements",
    "subtopic": "Stock split EPS",
    "difficulty": "BRUTAL",
    "stem": "A company had 10 million shares outstanding all year and earned $24 million for common shareholders. On 31 December, before the financial statements are issued, it completes a 2-for-1 stock split. The EPS presented for the year should be closest to:",
    "options": [
      "$4.80",
      "$2.40",
      "$1.20"
    ],
    "correct": 2,
    "explanation": "A stock split is applied retroactively to the weighted-average share count for EPS comparability. The split doubles the denominator from 10m to 20m without changing income, giving EPS of $24m / 20m = $1.20. Treating the split as occurring only after year-end would incorrectly report $2.40.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-income-statements"
  },
  {
    "id": "q213",
    "subject": "FSA",
    "topic": "Analyzing Income Statements",
    "subtopic": "Diluted EPS convertible debt",
    "difficulty": "EXTREME",
    "stem": "Net income is $30 million and basic weighted-average shares are 10 million. The company has convertible debt with $1.2 million annual interest; the tax rate is 25%. Conversion would create 1 million additional common shares. If the debt is dilutive, diluted EPS is closest to:",
    "options": [
      "$2.84",
      "$3.00",
      "$2.81"
    ],
    "correct": 2,
    "explanation": "Under the if-converted approach, add back after-tax interest: $1.2m × (1 − 0.25) = $0.9m. Adjusted earnings are $30.9m and adjusted shares are 11m, giving diluted EPS ≈ $2.81. Using pre-tax interest produces about $2.84; ignoring conversion leaves basic EPS at $3.00.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-income-statements"
  },
  {
    "id": "q214",
    "subject": "FSA",
    "topic": "Analyzing Income Statements",
    "subtopic": "Antidilutive securities",
    "difficulty": "BRUTAL",
    "stem": "A company reports basic EPS of $2.40. If assumed conversion of a convertible security would produce incremental EPS of $2.65, what is the most appropriate treatment in diluted EPS?",
    "options": [
      "Exclude the security because including it would increase EPS and therefore be antidilutive.",
      "Include it only if management expects conversion within the next year.",
      "Include it because every potentially convertible security must appear in diluted EPS."
    ],
    "correct": 0,
    "explanation": "Diluted EPS includes only securities that reduce EPS (or increase loss per share). Incremental EPS of $2.65 exceeds the current basic EPS of $2.40, so assumed conversion would raise EPS and is antidilutive. Expected timing of actual conversion is not the controlling test for the diluted-EPS calculation.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-income-statements"
  },
  {
    "id": "q215",
    "subject": "FSA",
    "topic": "Analyzing Income Statements",
    "subtopic": "Common-size income statement",
    "difficulty": "BRUTAL",
    "stem": "Company A's revenue rises 18%, gross profit rises 11%, and operating income rises 4%. Company B's revenue rises 8%, gross profit rises 9%, and operating income rises 12%. Without knowing absolute size, a common-size income-statement comparison most likely helps the analyst determine that:",
    "options": [
      "A's gross and operating margins are compressing, while B's operating margin is expanding.",
      "A necessarily created more shareholder value because its revenue growth was higher.",
      "B's gross margin must have fallen because gross profit grew only one percentage point faster than revenue."
    ],
    "correct": 0,
    "explanation": "Margins compare each profit measure with revenue. For A, gross profit and operating income grow more slowly than revenue, so both margins decline. For B, operating income grows faster than revenue, so operating margin rises; gross margin also rises slightly because gross profit growth exceeds sales growth. Absolute value creation cannot be inferred from growth rates alone.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-income-statements"
  },
  {
    "id": "q216",
    "subject": "FSA",
    "topic": "Analyzing Income Statements",
    "subtopic": "Gross versus operating margin",
    "difficulty": "HARD",
    "stem": "A retailer's gross margin increases from 32% to 35%, but its operating margin falls from 12% to 10%. Which explanation is most consistent with both changes?",
    "options": [
      "The company necessarily recognized a discontinued-operation gain in operating income.",
      "Product-level economics improved, but operating expenses below gross profit rose enough to more than offset the gain.",
      "Cost of goods sold rose as a percentage of sales while selling and administrative costs fell."
    ],
    "correct": 1,
    "explanation": "A higher gross margin means COGS consumed a smaller share of revenue. A lower operating margin despite that improvement implies expenses between gross profit and operating profit—such as selling or administrative costs—rose sufficiently. The opposite COGS/SG&A pattern would not produce the stated margins.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-income-statements"
  },
  {
    "id": "q217",
    "subject": "FSA",
    "topic": "Analyzing Income Statements",
    "subtopic": "Expense estimate change",
    "difficulty": "BRUTAL",
    "stem": "A manufacturer extends the estimated useful life of machinery from 8 to 12 years after two years of use, with no change in residual value and no evidence that the equipment's economics improved. The change reduces depreciation expense and helps the firm narrowly meet an earnings target. An analyst should most likely view the immediate effect as:",
    "options": [
      "higher current earnings and asset carrying values, with a need to scrutinize the estimate because the incentive may indicate aggressive reporting.",
      "lower current earnings because extending useful life accelerates depreciation.",
      "no effect on earnings because useful-life changes affect cash flow only."
    ],
    "correct": 0,
    "explanation": "Longer useful life generally lowers periodic depreciation prospectively, increasing current earnings and the remaining carrying amount relative to the old estimate. The timing near an earnings target and lack of supporting economics warrant skepticism. Depreciation is noncash, but its accounting effect on earnings is real.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-income-statements"
  },
  {
    "id": "q218",
    "subject": "FSA",
    "topic": "Analyzing Income Statements",
    "subtopic": "Discontinued operations",
    "difficulty": "BRUTAL",
    "stem": "A company sells a major business line that qualifies as a discontinued operation and reports a large after-tax gain. Continuing operations are unchanged. An analyst building a forecast of recurring operating earnings should most appropriately:",
    "options": [
      "separate the discontinued-operation result from continuing operations and avoid treating the gain as a recurring operating driver.",
      "remove the sold segment's historical revenue but retain the disposal gain in recurring earnings because the gain was realized in cash.",
      "include the gain in the operating margin because it increased total net income."
    ],
    "correct": 0,
    "explanation": "Discontinued operations are segregated specifically because they no longer represent continuing business performance. A realized gain can be genuine economic income yet still be unsuitable as a recurring forecast driver. Cash realization does not transform a disposal gain into sustainable operating margin.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-income-statements"
  },
  {
    "id": "q219",
    "subject": "FSA",
    "topic": "Analyzing Income Statements",
    "subtopic": "Revenue versus cash collection",
    "difficulty": "EXTREME",
    "stem": "A distributor reports 20% revenue growth while accounts receivable grows 55%, days sales outstanding rises sharply, and cash collected from customers grows only 4%. No acquisition occurred. Which interpretation is most analytically appropriate?",
    "options": [
      "Revenue growth may be economically real, but the divergence raises collection and revenue-quality questions that require further investigation.",
      "The revenue must be fraudulent because receivables grew faster than sales.",
      "The divergence is irrelevant because revenue recognition and cash collection are always unrelated."
    ],
    "correct": 0,
    "explanation": "Accrual revenue need not equal current-period cash collection, so the pattern does not prove fraud. But rapidly rising receivables and DSO relative to sales can signal looser credit, slower collections, or aggressive recognition. A strong analyst treats it as a warning signal and investigates terms, aging and subsequent collections.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-income-statements"
  },
  {
    "id": "q220",
    "subject": "FSA",
    "topic": "Analyzing Income Statements",
    "subtopic": "Operating leverage from common-size data",
    "difficulty": "EXTREME",
    "stem": "A service company has no material cost of goods sold. Revenue grows 10%, while salaries rise 5% and other operating costs remain unchanged. The common-size income statement shows salaries falling from 60% to 57% of revenue. Which conclusion is best?",
    "options": [
      "Operating margin must decline because salary expense increased in dollars.",
      "The company is demonstrating operating leverage from salary costs growing more slowly than revenue, all else equal.",
      "Salaries fell in absolute terms because their common-size percentage declined."
    ],
    "correct": 1,
    "explanation": "A common-size percentage can fall even when the absolute expense rises. Here salary growth of 5% is below revenue growth of 10%, so salary expense absorbs a smaller share of sales and contributes to operating leverage. With other costs unchanged, this supports, rather than impairs, operating margin.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-income-statements"
  },
  {
    "id": "q221",
    "subject": "FSA",
    "topic": "Analyzing Balance Sheets",
    "subtopic": "Goodwill",
    "difficulty": "BRUTAL",
    "stem": "Company P acquires Company T for more than the fair value of T's identifiable net assets, creating goodwill. One year later, P's market capitalization falls substantially, but management records no impairment and provides minimal sensitivity disclosure. Which analytical response is most appropriate?",
    "options": [
      "Write goodwill to zero immediately because any market-cap decline requires full impairment.",
      "Ignore the market-cap decline because goodwill can never affect financial analysis after acquisition.",
      "Treat the decline as a potential impairment indicator and scrutinize the assumptions supporting goodwill rather than automatically writing goodwill to zero."
    ],
    "correct": 2,
    "explanation": "Goodwill is not mechanically written off whenever market value falls, but a significant decline can be an impairment indicator and should prompt review of cash-generating assumptions and disclosures. Goodwill can materially affect assets and equity, so ignoring it is inappropriate; automatically eliminating it without analysis is also too strong.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-balance-sheets"
  },
  {
    "id": "q222",
    "subject": "FSA",
    "topic": "Analyzing Balance Sheets",
    "subtopic": "Intangible assets",
    "difficulty": "BRUTAL",
    "stem": "Two firms have equally valuable brands economically. Firm A bought its brand in an acquisition, while Firm B built its brand internally through years of advertising. A reports a much larger intangible-asset balance. Which inference is most appropriate?",
    "options": [
      "B must capitalize historical advertising retrospectively before any comparison can be made.",
      "A necessarily owns the more valuable brand because only purchased brands can have economic value.",
      "The balance-sheet difference may reflect recognition rules rather than a true difference in economic brand value, reducing comparability of book assets."
    ],
    "correct": 2,
    "explanation": "Accounting balance sheets recognize a narrower set of assets than an economic balance sheet. Purchased or acquisition-related intangibles can be recognized when internally generated brand value often is not. Thus reported assets can differ even when economics are similar. Analysts should understand the recognition asymmetry rather than equate book amount with economic value.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-balance-sheets"
  },
  {
    "id": "q223",
    "subject": "FSA",
    "topic": "Analyzing Balance Sheets",
    "subtopic": "Financial instruments measurement",
    "difficulty": "EXTREME",
    "stem": "A bank reports two bond portfolios with identical par value but different measurement bases under the applicable accounting rules. One portfolio is carried at a measure that updates with market prices; the other is not. Market yields rise sharply. Which analytical statement is most defensible?",
    "options": [
      "Both portfolios must show identical carrying-value declines because the bonds have the same par value.",
      "Reported balance-sheet sensitivity can differ because measurement basis matters; the analyst should understand classification and disclosure before comparing carrying values.",
      "Neither portfolio can affect equity because bond valuation changes never flow through financial statements."
    ],
    "correct": 1,
    "explanation": "Financial instruments can be measured differently depending on classification and reporting rules. Identical par value does not ensure identical carrying amounts or paths through income/equity. The correct analysis begins with classification, measurement and disclosures, not a blanket assumption about par value or financial-statement effects.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-balance-sheets"
  },
  {
    "id": "q224",
    "subject": "FSA",
    "topic": "Analyzing Balance Sheets",
    "subtopic": "Non-current liabilities",
    "difficulty": "BRUTAL",
    "stem": "A company refinances a large obligation after year-end but before the financial statements are authorized. A junior analyst classifies it as non-current solely because management says it “will be long term.” Which approach is better?",
    "options": [
      "Apply the relevant reporting framework's classification rules and examine the contractual rights and timing disclosed at the reporting date rather than management's label.",
      "Always classify it as current because all refinancing after year-end is economically irrelevant.",
      "Always classify the obligation as non-current if refinancing occurs before the analyst reads the statements."
    ],
    "correct": 0,
    "explanation": "Current versus non-current classification depends on the reporting framework and the entity's rights/conditions at the relevant date. Management intent or an analyst's reading date is not enough. This is precisely why notes and framework-specific requirements matter when assessing liquidity.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-balance-sheets"
  },
  {
    "id": "q225",
    "subject": "FSA",
    "topic": "Analyzing Balance Sheets",
    "subtopic": "Common-size balance sheet",
    "difficulty": "HARD",
    "stem": "A firm's inventory rises from 18% to 27% of total assets while receivables and cash percentages decline. Total assets grow only 2%. Which statement is most appropriate?",
    "options": [
      "Inventory necessarily rose by 50% in dollars because its common-size percentage rose from 18% to 27%.",
      "The firm's liquidity necessarily improved because inventory is a current asset.",
      "Inventory has become materially more important to the asset base, so turnover, obsolescence and working-capital risk deserve greater scrutiny."
    ],
    "correct": 2,
    "explanation": "Common-size analysis shows composition, not the exact percentage change in dollar inventory without calculation. A much larger share of assets tied up in inventory raises questions about turnover and quality. Inventory is less liquid than cash and may not improve practical liquidity merely because it is classified current.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-balance-sheets"
  },
  {
    "id": "q226",
    "subject": "FSA",
    "topic": "Analyzing Balance Sheets",
    "subtopic": "Book equity quality",
    "difficulty": "BRUTAL",
    "stem": "Two competitors report the same book equity. Firm A's assets consist mainly of cash and recently purchased equipment; Firm B's assets include large goodwill and aged receivables with rising delinquency. Which use of book equity is most defensible?",
    "options": [
      "Automatically subtract all goodwill and receivables from Firm B's equity without considering recoverability or analytical purpose.",
      "Conclude the firms have identical balance-sheet quality because assets minus liabilities equals the same equity amount.",
      "Treat equal book equity as an accounting starting point, but investigate asset composition and measurement quality before concluding the firms have similar financial strength."
    ],
    "correct": 2,
    "explanation": "Equal book equity can conceal very different asset quality and measurement uncertainty. Analysts should inspect composition, disclosures and recoverability. Automatically treating all goodwill or receivables as worthless is not justified, but ignoring their different risk characteristics is equally flawed.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-balance-sheets"
  },
  {
    "id": "q227",
    "subject": "FSA",
    "topic": "Analyzing Balance Sheets",
    "subtopic": "Debt ratio interpretation",
    "difficulty": "EXTREME",
    "stem": "A firm recognizes a previously unrecorded long-term liability of $40 million with a corresponding $40 million asset. Before recognition, assets were $200 million and liabilities $100 million. What happens to liabilities-to-assets?",
    "options": [
      "It rises from 50% to about 58.3%.",
      "It remains 50% because assets and liabilities increase by the same amount.",
      "It falls from 50% to about 41.7%."
    ],
    "correct": 0,
    "explanation": "Before recognition, liabilities/assets = 100/200 = 50%. After recognition, liabilities are 140 and assets 240, so the ratio is 140/240 = 58.3%. Equal dollar increases do not preserve a ratio unless numerator and denominator began equal. This is a common denominator trap in leverage analysis.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-balance-sheets"
  },
  {
    "id": "q228",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows I",
    "subtopic": "Indirect CFO",
    "difficulty": "BRUTAL",
    "stem": "Net income is $52 million. Depreciation is $9 million, receivables increase $7 million, inventory decreases $4 million, and accounts payable decreases $3 million. Ignore all other adjustments. CFO under the indirect method is:",
    "options": [
      "$55 million",
      "$49 million",
      "$61 million"
    ],
    "correct": 0,
    "explanation": "Start with net income of 52, add noncash depreciation 9, subtract the 7 increase in receivables, add the 4 decrease in inventory, and subtract the 3 decrease in payables: 52 + 9 − 7 + 4 − 3 = $55 million. The signs follow whether working capital consumed or released cash.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-i"
  },
  {
    "id": "q229",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows I",
    "subtopic": "Cash collected from customers",
    "difficulty": "BRUTAL",
    "stem": "Revenue is $420 million. Accounts receivable rises from $48 million to $63 million. There are no acquisitions, write-offs, or foreign-exchange effects. Cash collected from customers is closest to:",
    "options": [
      "$435 million",
      "$420 million",
      "$405 million"
    ],
    "correct": 2,
    "explanation": "An increase in receivables means some recognized revenue has not yet been collected. Cash collections = revenue − increase in receivables = 420 − 15 = $405 million. Adding the receivable increase reverses the economics; using revenue alone assumes all sales were collected.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-i"
  },
  {
    "id": "q230",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows I",
    "subtopic": "Cash paid to suppliers",
    "difficulty": "EXTREME",
    "stem": "COGS is $300 million. Inventory increases by $20 million and accounts payable increases by $12 million. Assume all inventory purchases are on account and no other adjustments apply. Cash paid to suppliers is closest to:",
    "options": [
      "$292 million",
      "$332 million",
      "$308 million"
    ],
    "correct": 2,
    "explanation": "Purchases = COGS + increase in inventory = 300 + 20 = 320. An increase in accounts payable means $12 million of purchases remains unpaid, so cash paid = 320 − 12 = $308 million. The common errors are adding the payable increase or adjusting COGS for only one balance-sheet account.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-i"
  },
  {
    "id": "q231",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows I",
    "subtopic": "Gain on sale indirect CFO",
    "difficulty": "BRUTAL",
    "stem": "A company sells equipment for cash and records a $6 million gain in net income. The full sale proceeds appear in investing cash flow. Under the indirect method, what adjustment is needed in CFO, all else equal?",
    "options": [
      "Subtract the $6 million gain from net income.",
      "Add the $6 million gain to net income.",
      "Make no adjustment because the sale proceeds are already in CFI."
    ],
    "correct": 0,
    "explanation": "The gain increased accounting net income but is not an operating cash flow; the actual sale proceeds are classified in investing. Therefore the indirect reconciliation removes the gain by subtracting it from net income. Failing to adjust would effectively allow the investing gain component to inflate CFO.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-i"
  },
  {
    "id": "q232",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows I",
    "subtopic": "Loss on sale indirect CFO",
    "difficulty": "HARD",
    "stem": "A company records a $4 million loss on disposal of equipment, with the sale proceeds classified as investing cash flow. In reconciling net income to CFO under the indirect method, the loss is most appropriately:",
    "options": [
      "ignored because losses are always cash items.",
      "added back to net income.",
      "subtracted from net income."
    ],
    "correct": 1,
    "explanation": "The loss reduced net income but the disposal cash flow belongs in investing. Adding the loss back removes its non-operating effect from the CFO reconciliation. The sale proceeds themselves remain in CFI.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-i"
  },
  {
    "id": "q233",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows I",
    "subtopic": "Working-capital signs",
    "difficulty": "EXTREME",
    "stem": "During the year, prepaid expenses increase $5 million, accrued operating liabilities increase $8 million, and all else is unchanged. Relative to net income, the net working-capital adjustment to CFO is:",
    "options": [
      "a $13 million decrease.",
      "a $3 million increase.",
      "a $3 million decrease."
    ],
    "correct": 1,
    "explanation": "An increase in a noncash operating asset such as prepaid expenses uses cash (−5), while an increase in an operating liability preserves cash (+8). Net adjustment is +3 million. Treating both increases with the same sign is the trap.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-i"
  },
  {
    "id": "q234",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows I",
    "subtopic": "Indirect-to-direct conversion",
    "difficulty": "EXTREME",
    "stem": "A firm reports revenue of $500 million, COGS of $310 million, receivables increasing $20 million, inventory decreasing $6 million, and payables decreasing $4 million. Ignoring taxes and other expenses, which pair is closest to cash collected from customers and cash paid to suppliers?",
    "options": [
      "$480 million and $308 million",
      "$480 million and $320 million",
      "$520 million and $300 million"
    ],
    "correct": 0,
    "explanation": "Collections = revenue − increase in receivables = 500 − 20 = 480. Purchases = COGS + ending inventory − beginning inventory = 310 − 6 = 304 because inventory decreased. Payables decreased 4, meaning cash paid exceeded purchases by 4, so supplier cash paid = 308. The question requires two linked balance-sheet adjustments.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-i"
  },
  {
    "id": "q235",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows I",
    "subtopic": "IFRS vs US GAAP classification",
    "difficulty": "BRUTAL",
    "stem": "An analyst compares two firms with identical economics but different reporting frameworks. One framework permits more classification choice for certain interest and dividend cash flows than the other. What is the most appropriate analytical response?",
    "options": [
      "Compare reported CFO directly because accounting-framework classification choices never affect cash-flow ratios.",
      "Reclassify cash flows to a common analytical basis when needed before comparing CFO, CFI, and CFF.",
      "Ignore total cash flow because classification differences also change the company's actual cash generated."
    ],
    "correct": 1,
    "explanation": "IFRS and US GAAP can classify certain interest and dividend cash flows differently. Those choices can change reported subtotals without changing total cash. For comparability, an analyst may need to reclassify to a consistent basis rather than interpret a presentation difference as an economic difference.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-i"
  },
  {
    "id": "q236",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows I",
    "subtopic": "Capex and depreciation",
    "difficulty": "BRUTAL",
    "stem": "A mature manufacturer reports depreciation of $40 million and capital expenditures of $18 million for three consecutive years while production capacity and unit volumes are stable. Which inference is most appropriate?",
    "options": [
      "The firm necessarily has understated CFO by $22 million because capex is lower than depreciation.",
      "The gap may indicate low replacement spending or asset-base contraction and deserves investigation; depreciation is not itself a cash funding source.",
      "The firm generated $22 million of free cash because depreciation always equals maintenance capital expenditure."
    ],
    "correct": 1,
    "explanation": "Depreciation is an accounting allocation, while capex is a cash investment. A persistent gap can reflect asset mix, prior investment cycles, maintenance needs or underinvestment. It cannot be interpreted mechanically as free cash or an error in CFO. Analysts should connect the cash-flow pattern to asset disclosures and operating capacity.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-i"
  },
  {
    "id": "q237",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows I",
    "subtopic": "Receivables and CFO quality",
    "difficulty": "BRUTAL",
    "stem": "Net income rises 25%, but CFO rises only 3% because receivables increase materially. Management says the difference is “noncash accounting noise.” Which interpretation is strongest?",
    "options": [
      "The receivable build is an operating cash-use that may be temporary or concerning, so the divergence should be investigated rather than dismissed.",
      "CFO should be ignored because accrual earnings are always superior for evaluating performance.",
      "The receivable increase proves customers will default."
    ],
    "correct": 0,
    "explanation": "Working-capital movements are real cash-timing effects. Rising receivables can reflect growth, seasonality, slower collection, looser credit or aggressive revenue recognition. The pattern does not prove default, but it is not meaningless accounting noise either. Analysts should investigate its cause and sustainability.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-i"
  },
  {
    "id": "q238",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows I",
    "subtopic": "Deferred revenue and CFO",
    "difficulty": "EXTREME",
    "stem": "A subscription company receives large annual prepayments from customers, causing contract liabilities (deferred revenue) to rise by $30 million. Revenue recognized this year is lower than cash collected. All else equal, the increase in the operating liability affects CFO relative to net income by:",
    "options": [
      "having no effect because deferred revenue is noncash.",
      "increasing CFO by $30 million.",
      "decreasing CFO by $30 million."
    ],
    "correct": 1,
    "explanation": "Cash was collected before all related revenue was recognized, creating an operating liability. Under the indirect method, an increase in such a liability is added in reconciling net income to CFO. The accounting liability itself is noncash, but its change reflects the earlier cash receipt.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-i"
  },
  {
    "id": "q239",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows I",
    "subtopic": "Cash-flow linkage",
    "difficulty": "EXTREME",
    "stem": "A company purchases equipment for cash, with no financing. Which set of immediate financial-statement effects is most consistent, ignoring taxes and any depreciation in the purchase period?",
    "options": [
      "Cash decreases, PP&E increases, CFO is negative, and total assets fall.",
      "Cash decreases, PP&E increases by the same amount, CFI is negative, and total assets are unchanged.",
      "Cash and PP&E are unchanged because investing transactions appear only on the cash-flow statement."
    ],
    "correct": 1,
    "explanation": "A cash purchase exchanges one asset for another: cash falls and PP&E rises, leaving total assets unchanged at purchase. The cash outflow is investing, not operating. Later depreciation affects income and carrying value, but it is excluded by the question's timing assumption.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-i"
  },
  {
    "id": "q240",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows II",
    "subtopic": "FCFF from CFO",
    "difficulty": "BRUTAL",
    "stem": "CFO is $86 million, capital expenditures are $30 million, cash interest paid is $10 million, and the tax rate is 25%. Assuming CFO is after interest, FCFF is closest to:",
    "options": [
      "$66.0 million",
      "$56.0 million",
      "$63.5 million"
    ],
    "correct": 2,
    "explanation": "When starting from CFO that includes interest paid, FCFF = CFO + interest × (1 − tax rate) − capex = 86 + 10×0.75 − 30 = $63.5 million. Simply subtracting capex gives FCFE-like pre-borrowing cash; adding full pretax interest overstates the tax-adjusted financing add-back.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-ii"
  },
  {
    "id": "q241",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows II",
    "subtopic": "FCFE from CFO",
    "difficulty": "BRUTAL",
    "stem": "A firm reports CFO of $72 million, capital expenditures of $28 million, debt issued of $15 million, and debt repaid of $9 million. FCFE is closest to:",
    "options": [
      "$44 million",
      "$50 million",
      "$56 million"
    ],
    "correct": 1,
    "explanation": "FCFE = CFO − capex + net borrowing. Net borrowing = 15 − 9 = 6, so FCFE = 72 − 28 + 6 = $50 million. Ignoring borrowing gives $44 million; adding gross borrowing without debt repayment gives $59 million, not the economics available to common equity.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-ii"
  },
  {
    "id": "q242",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows II",
    "subtopic": "Common-size cash flow statement",
    "difficulty": "HARD",
    "stem": "A company reports CFO equal to 14% of revenue this year versus 9% last year, while net margin is unchanged. Which conclusion is most appropriate?",
    "options": [
      "Operating cash conversion improved relative to sales, but the analyst should identify whether working-capital timing or sustainable operating changes caused it.",
      "The company's capital expenditures must have declined because CFO/revenue rose.",
      "Earnings quality necessarily improved permanently because CFO/revenue increased."
    ],
    "correct": 0,
    "explanation": "Common-size cash-flow analysis can reveal better cash conversion, but a one-year improvement may result from stretching payables, collecting receivables, seasonality or sustainable economics. CFO says nothing directly about capex because capex is investing. Interpretation requires sources and uses, not a mechanical quality conclusion.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-ii"
  },
  {
    "id": "q243",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows II",
    "subtopic": "Cash flow coverage",
    "difficulty": "BRUTAL",
    "stem": "Two firms have the same interest coverage based on EBIT. Firm A consistently converts 95% of operating profit into CFO; Firm B converts 45% because receivables and inventory absorb cash. For near-term debt-service analysis, which observation is most important?",
    "options": [
      "The firms have identical debt-service capacity because EBIT interest coverage is the same.",
      "Firm B is safer because higher working capital always represents collateral that can immediately pay interest.",
      "Firm A's stronger cash conversion may support better practical debt-service capacity even though accrual interest coverage is identical."
    ],
    "correct": 2,
    "explanation": "Accrual coverage ratios are useful but do not replace cash-flow analysis. Persistent working-capital absorption can leave less cash available for interest and principal. Inventory and receivables may be valuable, but they are not equivalent to immediately available cash and can carry collection or obsolescence risk.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-ii"
  },
  {
    "id": "q244",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows II",
    "subtopic": "FCFF versus FCFE",
    "difficulty": "EXTREME",
    "stem": "A highly leveraged company is paying down debt aggressively. Its operations and capital expenditures are stable. Which statement best explains why FCFE may be materially below FCFF during the deleveraging period?",
    "options": [
      "Debt repayment reduces EBIT and therefore automatically reduces FCFF dollar-for-dollar.",
      "FCFF is always lower than FCFE because FCFF excludes debt holders.",
      "FCFE reflects cash available after net borrowing; net debt repayment is a use of cash attributable to equity holders that does not reduce FCFF in the same way."
    ],
    "correct": 2,
    "explanation": "FCFF is cash available to all capital providers before financing distributions, while FCFE incorporates net borrowing. When debt repayment exceeds new borrowing, net borrowing is negative and reduces FCFE. Principal repayment is financing, not an operating expense that reduces EBIT dollar-for-dollar.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-ii"
  },
  {
    "id": "q245",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows II",
    "subtopic": "Cash generation sustainability",
    "difficulty": "EXTREME",
    "stem": "A company reports record CFO after delaying supplier payments; accounts payable days jump from 42 to 78 while sales are flat. Which adjustment is most useful for forecasting normalized cash generation?",
    "options": [
      "Recognize that the payable increase temporarily boosted CFO and test a scenario in which payment days normalize.",
      "Treat the full CFO increase as permanent because reported cash cannot be manipulated by operating decisions.",
      "Subtract the entire accounts-payable balance from current CFO rather than analyzing the change."
    ],
    "correct": 0,
    "explanation": "Stretching payables conserves cash in the current period and can increase CFO without improving underlying profitability. The relevant cash-flow effect is the period change and its sustainability, not the total liability balance. A normalized forecast should consider reversal if payment terms return toward historical levels.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-ii"
  },
  {
    "id": "q246",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows II",
    "subtopic": "FCFF versus FCFE financing effect",
    "difficulty": "EXTREME",
    "stem": "A company reports CFO of $120 million and capital expenditures of $70 million. During the year it issues $10 million of debt and repays $35 million. An analyst is comparing FCFF with FCFE and says the $25 million net debt repayment should reduce both measures equally. Which correction is most appropriate?",
    "options": [
      "The analyst is correct because any cash debt repayment is an operating use of cash in both free-cash-flow measures.",
      "Net debt repayment raises FCFF but lowers FCFE because lenders are part of enterprise value.",
      "Net debt repayment reduces FCFE through net borrowing, but it does not directly reduce FCFF because FCFF is measured before financing flows."
    ],
    "correct": 2,
    "explanation": "Net borrowing is $10m − $35m = −$25m. FCFE incorporates financing with creditors, so from CFO it is $120m − $70m − $25m = $25m. FCFF is cash flow available to all capital providers before debt financing transactions; issuing or repaying principal therefore does not directly enter FCFF. The key distinction is the claimant perspective, not whether the debt repayment is a real cash outflow.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-ii"
  },
  {
    "id": "q247",
    "subject": "FSA",
    "topic": "Analyzing Statements of Cash Flows II",
    "subtopic": "Source and use interpretation",
    "difficulty": "BRUTAL",
    "stem": "A young firm has negative CFO, large positive CFF from new debt and equity, and large negative CFI from capacity expansion. Which statement is most defensible?",
    "options": [
      "Negative CFO proves the business model is economically unviable regardless of life-cycle stage.",
      "Positive CFF demonstrates strong internally generated cash flow.",
      "The pattern can be consistent with a growth-stage firm, but sustainability depends on whether future operations generate enough cash before external financing becomes constrained."
    ],
    "correct": 2,
    "explanation": "Cash-flow patterns must be interpreted in business context. A growth company can consume operating and investing cash while raising external capital. That does not prove failure, but it creates financing dependence and requires analysis of unit economics, runway and eventual operating cash generation. CFF is external financing, not internally generated cash.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-statements-of-cash-flows-ii"
  },
  {
    "id": "q248",
    "subject": "FSA",
    "topic": "Analysis of Inventories",
    "subtopic": "Rising prices FIFO/LIFO",
    "difficulty": "BRUTAL",
    "stem": "During a period of rising unit purchase costs, two otherwise identical US GAAP companies use FIFO and LIFO, respectively. Assuming inventory quantities are stable and there are no write-downs, the FIFO company will most likely report, relative to the LIFO company:",
    "options": [
      "higher ending inventory and lower gross profit.",
      "higher ending inventory and higher gross profit.",
      "lower ending inventory and higher gross profit."
    ],
    "correct": 1,
    "explanation": "With rising costs, FIFO assigns older lower costs to COGS and newer higher costs to ending inventory. That produces lower COGS, higher gross profit and higher inventory than LIFO. The direction reverses under sustained falling costs, which is why the inflation/deflation condition matters.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-inventories"
  },
  {
    "id": "q249",
    "subject": "FSA",
    "topic": "Analysis of Inventories",
    "subtopic": "Inventory turnover under rising prices",
    "difficulty": "EXTREME",
    "stem": "During inflation, Firm F uses FIFO and Firm L uses LIFO. Their physical inventory flows and sales are identical. Relative to F, L will generally show which combination solely from the cost-flow assumption?",
    "options": [
      "lower COGS and higher average inventory, tending to produce lower inventory turnover.",
      "the same COGS and inventory turnover because cost-flow assumptions affect only taxes.",
      "higher COGS and lower average inventory, tending to produce higher inventory turnover."
    ],
    "correct": 2,
    "explanation": "Under rising costs, LIFO sends newer higher costs to COGS and leaves older lower costs in inventory. Both a higher numerator (COGS) and lower denominator (average inventory) tend to raise LIFO inventory turnover relative to FIFO. The accounting method affects several statement amounts and ratios, not just tax.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-inventories"
  },
  {
    "id": "q250",
    "subject": "FSA",
    "topic": "Analysis of Inventories",
    "subtopic": "Deflation FIFO/LIFO",
    "difficulty": "BRUTAL",
    "stem": "Unit costs fall steadily during the year. Compared with LIFO, FIFO will most likely report:",
    "options": [
      "higher gross profit and higher ending inventory.",
      "higher COGS and lower ending inventory.",
      "lower COGS and higher ending inventory."
    ],
    "correct": 1,
    "explanation": "Under deflation, the oldest units are the higher-cost units. FIFO expenses those higher costs first, producing higher COGS and lower ending inventory than LIFO. A candidate who memorizes the inflation relationship without conditioning on cost direction will reverse the answer.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-inventories"
  },
  {
    "id": "q251",
    "subject": "FSA",
    "topic": "Analysis of Inventories",
    "subtopic": "Lower of cost and NRV",
    "difficulty": "BRUTAL",
    "stem": "Inventory carried at cost of $9.0 million has estimated selling price of $9.6 million and estimated completion and selling costs of $1.1 million. Using lower of cost and net realisable value, the carrying amount is closest to:",
    "options": [
      "$9.0 million",
      "$8.5 million",
      "$9.6 million"
    ],
    "correct": 1,
    "explanation": "NRV = estimated selling price − costs to complete and sell = 9.6 − 1.1 = $8.5 million. Because NRV is below cost of $9.0 million, inventory is written down to $8.5 million. Using selling price alone ignores costs necessary to realize the inventory.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-inventories"
  },
  {
    "id": "q252",
    "subject": "FSA",
    "topic": "Analysis of Inventories",
    "subtopic": "Inventory write-down ratio effect",
    "difficulty": "EXTREME",
    "stem": "A company writes inventory down by $6 million because NRV fell below carrying cost. Ignore taxes and assume the write-down is recognized in expense. Immediately after the write-down, which pair of effects is most likely?",
    "options": [
      "Lower current assets and lower profit, with inventory turnover mechanically higher if COGS includes the write-down and average inventory is lower.",
      "No balance-sheet effect because an inventory write-down is only a disclosure item.",
      "Higher current assets and higher profit because the write-down improves inventory quality."
    ],
    "correct": 0,
    "explanation": "A write-down reduces the inventory asset and recognized profit. Depending on presentation, the charge also raises expense/COGS, while the inventory denominator falls, which can mechanically increase turnover even though the underlying economics worsened. Analysts should therefore avoid interpreting a post-write-down turnover improvement as operational progress.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-inventories"
  },
  {
    "id": "q253",
    "subject": "FSA",
    "topic": "Analysis of Inventories",
    "subtopic": "Inventory disclosure warning",
    "difficulty": "BRUTAL",
    "stem": "A fashion retailer's inventory grows 35% while sales grow 4%. The notes show finished goods rising fastest, markdowns increasing, and inventory turnover falling. Management says the increase is “strategic.” Which conclusion is most appropriate?",
    "options": [
      "The inventory growth is automatically bullish because more inventory allows more future sales.",
      "The pattern proves inventory is overstated because turnover fell.",
      "The pattern raises obsolescence and margin-risk concerns and should be tested against subsequent sales and markdown activity."
    ],
    "correct": 2,
    "explanation": "Inventory growth can support future sales, but disproportionate finished-goods growth, rising markdowns and slower turnover are warning signs for obsolescence and future margin pressure. They do not prove misstatement. High-integrity analysis treats the signals as evidence requiring corroboration, not as a predetermined conclusion.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-inventories"
  },
  {
    "id": "q254",
    "subject": "FSA",
    "topic": "Analysis of Inventories",
    "subtopic": "LIFO reserve comparability",
    "difficulty": "EXTREME",
    "stem": "An analyst compares a FIFO company with a LIFO company during sustained inflation. The LIFO company's notes disclose a large, rising difference between FIFO-equivalent inventory and reported LIFO inventory. What is the most appropriate use of this disclosure?",
    "options": [
      "Add the reserve to COGS and subtract it from inventory regardless of the direction of change.",
      "Adjust inventory and related measures toward a common cost basis when comparing balance-sheet and profitability ratios, recognizing the tax effects where relevant.",
      "Ignore the disclosure because LIFO and FIFO differences reverse automatically each year."
    ],
    "correct": 1,
    "explanation": "The reserve helps bridge LIFO inventory toward FIFO for comparability. Analysts can use it—and changes in it—to adjust inventory, COGS and related ratios on a consistent basis, with attention to taxes. The reserve is not simply added to COGS, and accumulated method differences do not necessarily reverse each year.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-inventories"
  },
  {
    "id": "q255",
    "subject": "FSA",
    "topic": "Analysis of Inventories",
    "subtopic": "Method economics vs cash",
    "difficulty": "HARD",
    "stem": "Two firms with identical physical purchases and sales use different permitted inventory cost-flow assumptions. One reports higher gross profit solely because of the accounting method. Which statement is most accurate?",
    "options": [
      "Higher reported gross profit necessarily means the firm sold products at higher economic margins.",
      "The gross-profit difference may be accounting-driven, so the analyst should normalize for method differences before inferring superior operating economics.",
      "Inventory accounting can change reported cash receipts from customers even when transactions are identical."
    ],
    "correct": 1,
    "explanation": "Cost-flow assumptions change how historical costs are allocated between COGS and inventory, so reported margins can differ without different selling prices or physical economics. Cash received from customers is determined by actual collections, not the inventory accounting assumption.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-inventories"
  },
  {
    "id": "q256",
    "subject": "FSA",
    "topic": "Analysis of Long-Term Assets",
    "subtopic": "Purchased vs internally generated intangibles",
    "difficulty": "BRUTAL",
    "stem": "Company A acquires a patent from another firm for $15 million. Company B spends $15 million over several years developing brand awareness internally. Both assets are economically useful. Which statement best captures the analytical issue?",
    "options": [
      "Neither expenditure can affect reported assets because intangible assets are never recognized.",
      "Accounting recognition can differ materially between purchased and internally generated intangibles, so asset intensity and return ratios may not be directly comparable.",
      "Both expenditures must appear as identical intangible assets because the cash amounts are equal."
    ],
    "correct": 1,
    "explanation": "Financial reporting recognizes purchased and qualifying acquired intangibles more readily than many internally generated intangibles. That asymmetry can make two economically similar companies look different in assets, margins and return ratios. Cash amount alone does not determine recognition.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-long-term-assets"
  },
  {
    "id": "q257",
    "subject": "FSA",
    "topic": "Analysis of Long-Term Assets",
    "subtopic": "Capitalization effect on ROA",
    "difficulty": "EXTREME",
    "stem": "Two firms have identical operating economics. Firm C capitalizes a qualifying cost that Firm E expenses. In the initial period before material amortization, C reports higher net income and higher assets. Which effect on ROA is unambiguously determined?",
    "options": [
      "ROA must be higher for C because net income is higher.",
      "ROA must be lower for C because assets are higher.",
      "It is not unambiguously determined because both the numerator and denominator are higher; the net ROA effect depends on magnitudes."
    ],
    "correct": 2,
    "explanation": "Capitalization raises both current income and the asset base relative to expensing. Because ROA is a ratio of profit to assets, the direction depends on the relative percentage effects. This is a classic ratio trap: knowing the signs of numerator and denominator changes is not enough when both move in the same direction.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-long-term-assets"
  },
  {
    "id": "q258",
    "subject": "FSA",
    "topic": "Analysis of Long-Term Assets",
    "subtopic": "Impairment effect",
    "difficulty": "BRUTAL",
    "stem": "A company records a material impairment of equipment. Ignore taxes. Immediately after recognition, all else equal, the company will most likely have:",
    "options": [
      "lower assets but unchanged equity because impairments are noncash.",
      "lower assets, lower equity, and higher asset turnover if revenue is unchanged.",
      "higher assets, lower equity, and lower asset turnover."
    ],
    "correct": 1,
    "explanation": "The impairment reduces the asset carrying amount and current earnings, which lowers equity. Because the asset denominator falls while revenue is unchanged, asset turnover can rise mechanically. Noncash does not mean no accounting effect; it means no immediate cash outflow.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-long-term-assets"
  },
  {
    "id": "q259",
    "subject": "FSA",
    "topic": "Analysis of Long-Term Assets",
    "subtopic": "Derecognition gain",
    "difficulty": "EXTREME",
    "stem": "Equipment with carrying value $18 million is sold for $23 million cash. Ignoring tax, which statement is most accurate?",
    "options": [
      "The company records a $5 million gain; cash inflow is $23 million in investing activities, while the gain is removed from CFO under the indirect method.",
      "The company records $23 million operating income because all sale proceeds are profit.",
      "The company records a $5 million investing cash inflow because only the gain is cash."
    ],
    "correct": 0,
    "explanation": "Gain equals proceeds minus carrying value: 23 − 18 = $5 million. The full $23 million sale proceeds are the investing cash flow. Under the indirect CFO method, the $5 million gain included in net income is subtracted because it is tied to an investing transaction.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-long-term-assets"
  },
  {
    "id": "q260",
    "subject": "FSA",
    "topic": "Analysis of Long-Term Assets",
    "subtopic": "Useful-life estimate",
    "difficulty": "BRUTAL",
    "stem": "A capital-intensive company reports much longer useful lives for similar equipment than peers, resulting in lower annual depreciation. No operational evidence supports longer lives. What is the most appropriate analytical implication?",
    "options": [
      "Useful-life assumptions affect only cash flow and therefore cannot influence valuation ratios.",
      "The longer useful life proves the company maintains equipment more efficiently.",
      "Reported earnings and asset carrying amounts may be higher than under peer-like estimates, so depreciation assumptions deserve normalization or sensitivity analysis."
    ],
    "correct": 2,
    "explanation": "Longer estimated lives reduce annual depreciation and keep asset carrying values higher. That can lift reported earnings and alter asset-based ratios without changing current cash. The assumption may be valid, but the absence of operating evidence and peer divergence warrant testing rather than acceptance or automatic rejection.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-long-term-assets"
  },
  {
    "id": "q261",
    "subject": "FSA",
    "topic": "Analysis of Long-Term Assets",
    "subtopic": "Revaluation comparability",
    "difficulty": "EXTREME",
    "stem": "An IFRS reporter uses a permitted revaluation approach for a class of long-lived assets, while a US GAAP peer carries comparable assets under the cost model. Asset prices have risen sharply. Which comparison is most likely distorted if made without adjustment?",
    "options": [
      "Book asset values and asset-based return ratios, because the measurement bases differ.",
      "Cash generated by operations, because revaluation itself creates cash receipts.",
      "Physical productive capacity, because accounting revaluation automatically changes the assets' output."
    ],
    "correct": 0,
    "explanation": "Different measurement models can create large book-value differences even with similar physical assets. That affects denominators such as assets and equity and therefore return ratios. A revaluation is an accounting measurement event; it does not itself generate operating cash or change physical capacity.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-long-term-assets"
  },
  {
    "id": "q262",
    "subject": "FSA",
    "topic": "Analysis of Long-Term Assets",
    "subtopic": "Asset age analysis",
    "difficulty": "BRUTAL",
    "stem": "A manufacturer reports gross PP&E of $600 million and accumulated depreciation of $480 million, while capex has been below depreciation for several years. Which inference is most appropriate?",
    "options": [
      "The asset base may be relatively mature and future replacement needs could be higher than recent capex, but disclosures and operating context are needed before concluding underinvestment.",
      "Accumulated depreciation represents cash reserved for future replacement.",
      "The firm must spend exactly $480 million immediately to replace depreciated assets."
    ],
    "correct": 0,
    "explanation": "High accumulated depreciation relative to gross PP&E and low recent capex can indicate an aged asset base, but accounting depreciation is not a replacement reserve and does not dictate exact future spending. Analysts should combine age, maintenance, capacity and capex disclosures before forecasting.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-long-term-assets"
  },
  {
    "id": "q263",
    "subject": "FSA",
    "topic": "Analysis of Long-Term Assets",
    "subtopic": "Impairment future ratios",
    "difficulty": "EXTREME",
    "stem": "After a large impairment, a firm's next-year operating economics are unchanged and no further impairment occurs. Compared with a hypothetical no-impairment path, next-year return on assets may appear higher primarily because:",
    "options": [
      "the prior impairment reduced the asset denominator, even though the underlying operating economics did not improve.",
      "the impairment creates operating cash that increases next-year earnings.",
      "the impairment permanently raises revenue by reducing depreciation."
    ],
    "correct": 0,
    "explanation": "An impairment lowers the carrying amount of assets. With similar future earnings, the smaller denominator can mechanically increase ROA. Depending on the asset and accounting, future depreciation may also change, but the central analytical point is that post-impairment ratios can improve mechanically without better economics.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-long-term-assets"
  },
  {
    "id": "q264",
    "subject": "FSA",
    "topic": "Topics in Long-Term Liabilities and Equity",
    "subtopic": "Lease financing perspective",
    "difficulty": "BRUTAL",
    "stem": "A retailer expands using long-term leases rather than purchasing stores with borrowed funds. A junior analyst says leases should be ignored in solvency analysis because “rent is an operating choice, not financing.” Which response is most appropriate?",
    "options": [
      "All future lease payments should automatically be treated as current liabilities.",
      "Lease obligations can create fixed long-term payment commitments and should be incorporated into leverage and coverage analysis based on their reported treatment and disclosures.",
      "The junior analyst is correct because only bonds and bank loans can create financial leverage."
    ],
    "correct": 1,
    "explanation": "Leases are a common alternative to asset ownership and can create economically significant fixed commitments. Modern reporting recognizes many lease assets and liabilities, and disclosures matter for solvency analysis. Treating every future payment as current is incorrect, but ignoring leases understates contractual obligations.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/topics-in-long-term-liabilities-and-equity"
  },
  {
    "id": "q265",
    "subject": "FSA",
    "topic": "Topics in Long-Term Liabilities and Equity",
    "subtopic": "Defined contribution vs defined benefit",
    "difficulty": "BRUTAL",
    "stem": "Two employers promise retirement benefits. Employer D contributes a fixed percentage of salary to employee accounts and has no further obligation for investment performance. Employer B promises a formula-based pension tied to salary and service. Which company bears more direct investment and actuarial risk?",
    "options": [
      "Employer D, because fixed contributions make the employer responsible for each employee's investment return.",
      "Neither; pension structure cannot affect the employer's balance-sheet risk.",
      "Employer B, because the defined-benefit promise depends on future benefit obligations and plan assets rather than a fixed contribution alone."
    ],
    "correct": 2,
    "explanation": "A defined-contribution plan generally fixes the employer's contribution, leaving investment outcomes with employees. A defined-benefit plan promises benefits and can create funded-status, actuarial and investment risk for the employer. The distinction is economically important for liabilities and disclosures.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/topics-in-long-term-liabilities-and-equity"
  },
  {
    "id": "q266",
    "subject": "FSA",
    "topic": "Topics in Long-Term Liabilities and Equity",
    "subtopic": "Pension funded status",
    "difficulty": "EXTREME",
    "stem": "A company has pension plan assets of $420 million and a defined-benefit obligation of $470 million. Ignoring other pension accounting details, which economic interpretation is most appropriate?",
    "options": [
      "There is no economic funding gap until retirees actually receive cash payments.",
      "The plan is overfunded by $50 million because the plan assets are financial assets.",
      "The plan is underfunded by $50 million, indicating a net pension obligation that matters to solvency analysis."
    ],
    "correct": 2,
    "explanation": "At a high level, plan assets of 420 against benefit obligations of 470 imply a $50 million deficit. Detailed accounting presentation can involve additional rules, but an analyst should recognize the unfunded economic obligation rather than ignore it until cash benefits are paid.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/topics-in-long-term-liabilities-and-equity"
  },
  {
    "id": "q267",
    "subject": "FSA",
    "topic": "Topics in Long-Term Liabilities and Equity",
    "subtopic": "Stock-based compensation",
    "difficulty": "BRUTAL",
    "stem": "A technology company excludes stock-based compensation from its preferred non-GAAP earnings measure, arguing that it is “noncash.” The company issues significant new equity awards every year. Which analytical treatment is most defensible?",
    "options": [
      "Exclude it permanently because any expense without an immediate cash outflow cannot reduce shareholder value.",
      "Add it back to earnings and ignore share-count effects because awards affect only employees.",
      "Treat stock-based compensation as an economic cost and consider dilution; noncash classification does not make recurring employee compensation free."
    ],
    "correct": 2,
    "explanation": "Stock-based compensation is compensation paid with an ownership claim rather than current cash. Recurring awards can dilute existing shareholders and are an economic cost even if they are noncash when expensed. A non-GAAP add-back may be useful for a particular purpose, but it should not erase the underlying cost or dilution.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/topics-in-long-term-liabilities-and-equity"
  },
  {
    "id": "q268",
    "subject": "FSA",
    "topic": "Topics in Long-Term Liabilities and Equity",
    "subtopic": "Lease disclosure comparability",
    "difficulty": "EXTREME",
    "stem": "Company A owns its distribution centers and finances them with debt. Company B leases similar centers. Reported operating margins are close. For a leverage comparison, which approach is strongest?",
    "options": [
      "Add the full undiscounted lifetime lease payments to current debt without considering timing or reporting treatment.",
      "Compare only reported bank debt because operating assets should never influence capital structure analysis.",
      "Consider both recognized debt and lease obligations and understand how ownership versus leasing changes expense and cash-flow presentation before comparing solvency."
    ],
    "correct": 2,
    "explanation": "Ownership financed by debt and long-term leasing can create similar economic commitments but different statement presentation. A robust comparison incorporates lease liabilities/commitments and their effect on coverage while respecting timing and measurement, rather than ignoring them or adding undiscounted future payments mechanically.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/topics-in-long-term-liabilities-and-equity"
  },
  {
    "id": "q269",
    "subject": "FSA",
    "topic": "Topics in Long-Term Liabilities and Equity",
    "subtopic": "Share-based compensation disclosure",
    "difficulty": "HARD",
    "stem": "A firm reports flat diluted EPS despite 12% net-income growth. Its notes show large employee option exercises and restricted-share vesting. Which interpretation is most appropriate?",
    "options": [
      "Equity compensation may be increasing the diluted share count enough to offset earnings growth on a per-share basis.",
      "Flat diluted EPS proves the reported net-income growth is misstated.",
      "Share-based compensation can affect equity but never EPS."
    ],
    "correct": 0,
    "explanation": "Per-share outcomes depend on both earnings and the diluted share denominator. New or vesting equity awards can increase dilution, causing EPS growth to lag net income even when the income number is accurate. The notes help explain the bridge between company-level profit and shareholder-level per-share economics.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/topics-in-long-term-liabilities-and-equity"
  },
  {
    "id": "q270",
    "subject": "FSA",
    "topic": "Topics in Long-Term Liabilities and Equity",
    "subtopic": "Debt covenant disclosure",
    "difficulty": "BRUTAL",
    "stem": "A company has a long-term loan covenant requiring debt/EBITDA below 4.0×. Reported ratio is 3.9×, but management's EBITDA adds back a large recurring “transformation” expense. Which analytical step is most important?",
    "options": [
      "Ignore the covenant until the company actually defaults.",
      "Recalculate covenant and economic leverage using the contractual definition and assess whether recurring add-backs overstate practical headroom.",
      "Accept 3.9× because any management-defined EBITDA is automatically the covenant measure."
    ],
    "correct": 1,
    "explanation": "Long-term-liability analysis requires reading contractual and disclosure details. The formal covenant definition determines legal compliance, while recurring add-backs can still make economic leverage look better than underlying cash generation. Waiting for default would miss the forward-looking solvency risk.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/topics-in-long-term-liabilities-and-equity"
  },
  {
    "id": "q271",
    "subject": "FSA",
    "topic": "Topics in Long-Term Liabilities and Equity",
    "subtopic": "Fixed obligations and operating risk",
    "difficulty": "EXTREME",
    "stem": "Two retailers have identical EBITDA before occupancy costs. One owns stores debt-free; the other has large long-term lease liabilities. During a 20% revenue decline, which firm is more exposed to fixed-payment pressure, all else equal?",
    "options": [
      "The heavily leased retailer, because contractual lease payments reduce financial flexibility even if they are tied to operating locations.",
      "The owner, because owned assets always create more fixed cash obligations than leases.",
      "Exposure is identical because EBITDA before occupancy is the same."
    ],
    "correct": 0,
    "explanation": "Fixed contractual payments matter in downside analysis. A large lease burden can behave like financing leverage by requiring cash payments despite revenue weakness. Identical pre-occupancy EBITDA does not imply identical financial flexibility, and asset ownership without debt does not create the same fixed creditor claim.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/topics-in-long-term-liabilities-and-equity"
  },
  {
    "id": "q272",
    "subject": "FSA",
    "topic": "Analysis of Income Taxes",
    "subtopic": "Temporary difference",
    "difficulty": "BRUTAL",
    "stem": "A company uses accelerated tax depreciation, so tax depreciation exceeds book depreciation in early years. The asset's carrying amount is therefore greater than its tax base. Assuming the difference will reverse and tax rates are positive, this most likely creates:",
    "options": [
      "a permanent difference with no deferred tax effect.",
      "a deferred tax asset.",
      "a deferred tax liability."
    ],
    "correct": 2,
    "explanation": "When an asset's carrying amount exceeds its tax base, future recovery of the carrying amount implies taxable amounts beyond future book amounts, creating a taxable temporary difference and generally a DTL. The key is that the timing difference reverses; it is not a permanent difference.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-income-taxes"
  },
  {
    "id": "q273",
    "subject": "FSA",
    "topic": "Analysis of Income Taxes",
    "subtopic": "Deferred tax asset",
    "difficulty": "BRUTAL",
    "stem": "A firm recognizes an expense for book purposes now, but the tax deduction will be available only when cash is paid in a later period. Assuming future taxable income is expected, the timing difference most likely creates:",
    "options": [
      "a deferred tax asset.",
      "a deferred tax liability.",
      "no deferred tax item because expense recognition always matches tax deduction."
    ],
    "correct": 0,
    "explanation": "The company has reduced book income before it receives the tax deduction. The future deduction is an economic tax benefit and generally creates a deductible temporary difference and DTA, subject to realizability considerations.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-income-taxes"
  },
  {
    "id": "q274",
    "subject": "FSA",
    "topic": "Analysis of Income Taxes",
    "subtopic": "Effective tax rate",
    "difficulty": "HARD",
    "stem": "Pretax accounting income is $200 million and income tax expense is $46 million. The statutory tax rate is 25%. The effective tax rate is:",
    "options": [
      "20%",
      "23%",
      "25%"
    ],
    "correct": 1,
    "explanation": "Effective tax rate = income tax expense / pretax accounting income = 46/200 = 23%. The 25% statutory rate is the legal benchmark, not the calculated ETR. Differences can arise from permanent items, jurisdictions, credits and other reconciling factors.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-income-taxes"
  },
  {
    "id": "q275",
    "subject": "FSA",
    "topic": "Analysis of Income Taxes",
    "subtopic": "Cash tax rate",
    "difficulty": "BRUTAL",
    "stem": "Pretax accounting income is $160 million, income tax expense is $40 million, and cash taxes paid are $28 million. Which pair is correct?",
    "options": [
      "Effective tax rate = 25%; cash tax rate = 17.5%.",
      "Effective tax rate = 17.5%; cash tax rate = 25%.",
      "Both rates = 25%."
    ],
    "correct": 0,
    "explanation": "ETR uses income tax expense: 40/160 = 25%. Cash tax rate uses cash taxes paid: 28/160 = 17.5%. The difference can reflect temporary differences, tax-payment timing and other items; one should not substitute cash taxes for income tax expense when computing ETR.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-income-taxes"
  },
  {
    "id": "q276",
    "subject": "FSA",
    "topic": "Analysis of Income Taxes",
    "subtopic": "Permanent difference",
    "difficulty": "BRUTAL",
    "stem": "A jurisdiction permanently disallows a category of expense for tax purposes. The expense reduces accounting profit but will never be deductible for tax. The difference is best described as:",
    "options": [
      "a temporary difference that necessarily creates a deferred tax liability.",
      "a temporary difference that necessarily creates a deferred tax asset.",
      "a permanent difference that can affect the effective tax rate but does not reverse into a deferred tax item."
    ],
    "correct": 2,
    "explanation": "Permanent differences never reverse between book and taxable income, so they do not create DTA/DTL balances. They can, however, cause the effective tax rate to differ from the statutory rate. Confusing permanent and timing differences is the central trap.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-income-taxes"
  },
  {
    "id": "q277",
    "subject": "FSA",
    "topic": "Analysis of Income Taxes",
    "subtopic": "DTA realizability",
    "difficulty": "EXTREME",
    "stem": "A loss-making company has a large deferred tax asset from tax-loss carryforwards but has generated cumulative losses for several years and management provides weak evidence of future taxable profit. For valuation, the analyst should most appropriately:",
    "options": [
      "treat the DTA as equivalent to cash because it appears in assets.",
      "question how much of the DTA is economically realizable and avoid treating the full accounting amount as cash-like value without support.",
      "subtract the DTA from enterprise value regardless of expected future taxable income."
    ],
    "correct": 1,
    "explanation": "A DTA has value only to the extent future taxable income or other tax-planning capacity allows the benefit to be used. Persistent losses can reduce realizability. The analyst should examine disclosures and assumptions rather than equate the accounting asset with cash or automatically assign it zero value.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-income-taxes"
  },
  {
    "id": "q278",
    "subject": "FSA",
    "topic": "Analysis of Income Taxes",
    "subtopic": "Tax rate reconciliation",
    "difficulty": "EXTREME",
    "stem": "A company's statutory tax rate is unchanged, but its effective tax rate falls from 27% to 16%. The tax note attributes most of the decline to a one-time release of a tax reserve. Which forecast assumption is most appropriate?",
    "options": [
      "Do not automatically extrapolate the 16% rate; separate the one-time reconciliation item and estimate a sustainable rate.",
      "Use 27% indefinitely because tax-note reconciliation items have no analytical value.",
      "Use 16% indefinitely because the most recent effective tax rate always dominates the statutory rate."
    ],
    "correct": 0,
    "explanation": "The tax-rate reconciliation explains why accounting tax expense differs from the statutory benchmark. A one-time reserve release can depress the current ETR without changing recurring tax economics. Forecasting should isolate it rather than blindly extrapolate either the current or historical rate.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-income-taxes"
  },
  {
    "id": "q279",
    "subject": "FSA",
    "topic": "Analysis of Income Taxes",
    "subtopic": "DTL analytical treatment",
    "difficulty": "BRUTAL",
    "stem": "A company has a large DTL arising from accelerated tax depreciation on long-lived assets. The company continually reinvests and the difference has historically grown rather than reversed. Which analytical treatment is most defensible?",
    "options": [
      "Recognize it as a liability but consider the expected timing of reversal when assessing its economic present value and leverage impact.",
      "Treat every DTL as immediately payable cash debt at full face value.",
      "Ignore every DTL because deferred taxes can never require future cash payment."
    ],
    "correct": 0,
    "explanation": "A DTL represents future tax consequences, but timing matters. Some differences can reverse far in the future or be extended by continuing investment. Analysts should neither treat all DTLs as immediate debt nor dismiss them. The expected reversal pattern matters to valuation and solvency.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analysis-of-income-taxes"
  },
  {
    "id": "q280",
    "subject": "FSA",
    "topic": "Financial Reporting Quality",
    "subtopic": "Reporting quality vs results quality",
    "difficulty": "BRUTAL",
    "stem": "A cyclical company reports a large loss caused by a genuine collapse in demand. Its statements are complete, unbiased, transparent, and faithfully represent the economics. Which classification is most appropriate?",
    "options": [
      "High reporting quality requires high and growing earnings.",
      "High reporting quality can coexist with low-quality economic results.",
      "A large loss automatically means low reporting quality."
    ],
    "correct": 1,
    "explanation": "Reporting quality concerns whether information faithfully represents economic reality. Results quality concerns the underlying economics and sustainability. A company can truthfully report poor, unsustainable results and therefore have high reporting quality despite weak economic performance.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/financial-reporting-quality"
  },
  {
    "id": "q281",
    "subject": "FSA",
    "topic": "Financial Reporting Quality",
    "subtopic": "Aggressive accounting",
    "difficulty": "BRUTAL",
    "stem": "A manager facing an earnings target lengthens asset useful lives, reduces the bad-debt allowance despite worsening collections, and excludes recurring restructuring costs from a highlighted non-GAAP metric. The pattern is most consistent with:",
    "options": [
      "conservative accounting because estimates are being revised rather than cash flows changed.",
      "high results quality because the choices are permitted within accounting standards.",
      "aggressive reporting choices designed to raise current earnings or perceived performance."
    ],
    "correct": 2,
    "explanation": "Aggressive reporting can arise through estimates and presentation choices even when each action remains within a range allowed by standards. Longer lives lower depreciation, a smaller allowance lowers expense, and recurring exclusions can make adjusted earnings look stronger. Permissibility does not make the economic presentation conservative or high quality.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/financial-reporting-quality"
  },
  {
    "id": "q282",
    "subject": "FSA",
    "topic": "Financial Reporting Quality",
    "subtopic": "CFO manipulation signal",
    "difficulty": "EXTREME",
    "stem": "A company reports a surge in CFO while sales and earnings are flat. Days payable outstanding jumps sharply, supplier complaints rise, and no purchasing efficiency is evident. Which interpretation is strongest?",
    "options": [
      "The payable increase proves the company has committed financial-statement fraud.",
      "CFO cannot be influenced by management operating choices, so the increase is necessarily high quality.",
      "The CFO improvement may reflect stretching payables rather than stronger operating economics and may reverse."
    ],
    "correct": 2,
    "explanation": "Delaying supplier payments conserves cash and boosts current CFO. That may be a legitimate working-capital decision or a sign of stress; it does not by itself prove fraud. But it weakens the inference that higher CFO represents sustainable operating improvement and should be normalized in analysis.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/financial-reporting-quality"
  },
  {
    "id": "q283",
    "subject": "FSA",
    "topic": "Financial Reporting Quality",
    "subtopic": "Benchmark beating pattern",
    "difficulty": "BRUTAL",
    "stem": "For 16 consecutive quarters, a company reports EPS one or two cents above analyst consensus despite volatile end markets. Accruals rise and cash conversion deteriorates. Which response is most appropriate?",
    "options": [
      "Treat the repeated narrow benchmark beats plus rising accruals as warning signs that warrant deeper investigation, not proof of manipulation.",
      "Conclude manipulation has occurred because beating consensus more than four quarters is conclusive evidence.",
      "Ignore the pattern because meeting market expectations is unrelated to reporting quality."
    ],
    "correct": 0,
    "explanation": "Repeatedly meeting or narrowly beating benchmarks can be a reporting-quality warning sign, particularly when accruals rise and cash conversion weakens. It is evidence for skepticism and follow-up, not definitive proof. A high-integrity analyst distinguishes a red flag from a finding of fraud.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/financial-reporting-quality"
  },
  {
    "id": "q284",
    "subject": "FSA",
    "topic": "Financial Reporting Quality",
    "subtopic": "Non-GAAP presentation",
    "difficulty": "BRUTAL",
    "stem": "Management highlights “core EBITDA” that excludes acquisition costs, stock compensation, restructuring, and litigation expenses. Three of the four categories have appeared every year for five years. Which analytical treatment is strongest?",
    "options": [
      "Reject every non-GAAP measure automatically, even if it provides useful segmentation of one-time items.",
      "Accept every exclusion because non-GAAP measures are designed to show the true business and therefore supersede GAAP/IFRS.",
      "Reconcile the measure to reported results and challenge exclusions that are economically recurring before using it as a sustainable earnings proxy."
    ],
    "correct": 2,
    "explanation": "Non-GAAP measures can be useful, but repeated exclusions can present an overly favorable view. The analyst should reconcile them, understand definitions and assess recurrence. Blind acceptance and blanket rejection are both weak; the issue is whether the adjusted measure faithfully supports the analytical purpose.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/financial-reporting-quality"
  },
  {
    "id": "q285",
    "subject": "FSA",
    "topic": "Financial Reporting Quality",
    "subtopic": "Mechanisms and limitations",
    "difficulty": "EXTREME",
    "stem": "A company has a Big Four auditor, an active securities regulator, and widely traded bonds, yet management still has strong incentives to avoid a covenant breach. Which conclusion is most appropriate?",
    "options": [
      "The presence of a major auditor and regulator makes low-quality reporting impossible.",
      "External discipline can improve reporting quality but does not eliminate management incentives or the need for analytical skepticism.",
      "Debt covenants always improve reporting quality because they remove incentives to manage earnings."
    ],
    "correct": 1,
    "explanation": "Auditors, regulators and capital markets are disciplinary mechanisms, not guarantees. Debt covenants can even create incentives to manage reported figures near thresholds. Analysts still need to assess estimates, disclosures and cash conversion rather than outsource judgment to institutional safeguards.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/financial-reporting-quality"
  },
  {
    "id": "q286",
    "subject": "FSA",
    "topic": "Financial Reporting Quality",
    "subtopic": "Capitalization warning",
    "difficulty": "BRUTAL",
    "stem": "A software company suddenly begins capitalizing a much larger share of development spending. Revenue growth is slowing, current earnings accelerate, CFO improves relative to prior treatment, and CFI becomes more negative. Which interpretation is most appropriate?",
    "options": [
      "More negative CFI proves the company is destroying value.",
      "The simultaneous rise in earnings and CFO proves the product economics improved.",
      "The accounting shift can improve current earnings and CFO presentation without improving total cash flow, so the analyst should test whether capitalization remains economically justified."
    ],
    "correct": 2,
    "explanation": "Capitalization moves qualifying spending from current expense to an asset and often from operating to investing cash flow. That can raise current earnings and CFO while leaving total cash unchanged. The change may be valid, but timing alongside weaker growth warrants scrutiny of criteria and future amortization.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/financial-reporting-quality"
  },
  {
    "id": "q287",
    "subject": "FSA",
    "topic": "Financial Reporting Quality",
    "subtopic": "Accrual persistence",
    "difficulty": "EXTREME",
    "stem": "Two firms report identical earnings growth. Firm A's growth is supported by cash collections and stable working-capital ratios. Firm B's growth comes mainly from rising receivables and other accruals. All else equal, which forecast is more defensible?",
    "options": [
      "Place greater confidence in A's earnings persistence while investigating whether B's accrual-heavy growth is sustainable.",
      "Forecast identical persistence because reported earnings growth is identical.",
      "Assume B's earnings are fraudulent because accruals increased."
    ],
    "correct": 0,
    "explanation": "Accrual-heavy earnings can be less persistent and can revert more quickly than cash-supported earnings, but accruals are a normal part of accounting and do not prove fraud. The stronger inference is relative forecast confidence and the need to investigate B's collection and recognition assumptions.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/financial-reporting-quality"
  },
  {
    "id": "q288",
    "subject": "FSA",
    "topic": "Financial Analysis Techniques",
    "subtopic": "Current vs quick ratio",
    "difficulty": "BRUTAL",
    "stem": "A retailer's current ratio rises from 1.6 to 1.9 solely because slow-moving inventory increases. Cash and receivables are unchanged, and current liabilities are unchanged. Which statement is most accurate?",
    "options": [
      "The current ratio improves mechanically, but the quick ratio is unchanged and practical liquidity may not improve.",
      "Liquidity necessarily improves because any increase in current assets is equally liquid.",
      "Both current and quick ratios rise because inventory is a current asset."
    ],
    "correct": 0,
    "explanation": "The current ratio includes inventory, while the quick ratio generally excludes it. An inventory build can therefore raise the current ratio without increasing cash-like resources. If inventory is slow-moving, the apparent liquidity improvement may be weak economically.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/financial-analysis-techniques"
  },
  {
    "id": "q289",
    "subject": "FSA",
    "topic": "Financial Analysis Techniques",
    "subtopic": "DuPont ROE",
    "difficulty": "BRUTAL",
    "stem": "A firm's net margin falls from 8% to 7%, asset turnover rises from 1.2× to 1.4×, and financial leverage falls from 2.0× to 1.8×. Using three-part DuPont, ROE changes from approximately:",
    "options": [
      "19.2% to 24.7%, an increase.",
      "19.2% to 17.6%, a decline.",
      "9.6% to 9.8%, roughly unchanged."
    ],
    "correct": 1,
    "explanation": "Three-part DuPont ROE = net margin × asset turnover × financial leverage. Old ROE = 0.08×1.2×2.0 = 19.2%. New ROE = 0.07×1.4×1.8 = 17.64%. Improved efficiency does not fully offset lower margin and leverage.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/financial-analysis-techniques"
  },
  {
    "id": "q290",
    "subject": "FSA",
    "topic": "Financial Analysis Techniques",
    "subtopic": "Receivables turnover",
    "difficulty": "BRUTAL",
    "stem": "Credit sales are $600 million and average receivables are $75 million. If a peer has materially higher receivables turnover with similar customer mix and terms, the subject company's receivables turnover of:",
    "options": [
      "8.0× proves all receivables will be collected.",
      "8.0× may indicate slower collection relative to the peer and warrants investigation.",
      "0.125× proves the subject company has better credit quality."
    ],
    "correct": 1,
    "explanation": "Receivables turnover = credit sales / average receivables = 600/75 = 8.0×. Lower turnover than a comparable peer can indicate slower collection or looser credit, but it does not prove default or poor quality by itself. Industry terms and seasonality remain relevant.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/financial-analysis-techniques"
  },
  {
    "id": "q291",
    "subject": "FSA",
    "topic": "Financial Analysis Techniques",
    "subtopic": "Interest coverage",
    "difficulty": "EXTREME",
    "stem": "EBIT is $90 million and interest expense is $18 million. A proposed acquisition would add $24 million EBIT but $12 million interest expense. Ignoring integration effects, EBIT interest coverage changes from:",
    "options": [
      "5.0× to 3.8×, so operating profit rises but coverage deteriorates.",
      "5.0× to 6.3×, so coverage improves.",
      "3.8× to 5.0×, so leverage falls."
    ],
    "correct": 0,
    "explanation": "Current coverage = 90/18 = 5.0×. Pro forma EBIT = 114 and interest = 30, so coverage = 3.8×. The acquisition is accretive to EBIT but more than proportionately increases interest burden. Growth in the numerator alone does not guarantee better solvency.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/financial-analysis-techniques"
  },
  {
    "id": "q292",
    "subject": "FSA",
    "topic": "Financial Analysis Techniques",
    "subtopic": "ROE leverage trap",
    "difficulty": "BRUTAL",
    "stem": "A company repurchases shares using new debt. Net income is initially unchanged, assets are roughly unchanged, and book equity falls. ROE rises. Which interpretation is most appropriate?",
    "options": [
      "Debt-financed repurchases cannot affect ROE until net income changes.",
      "The higher ROE proves asset productivity improved.",
      "The higher ROE may be driven by greater financial leverage and a smaller equity denominator rather than improved operating profitability."
    ],
    "correct": 2,
    "explanation": "ROE can rise mechanically when equity falls and leverage rises. DuPont decomposition helps separate margin, asset efficiency and financial leverage. A higher post-repurchase ROE is not automatically evidence of better operating economics.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/financial-analysis-techniques"
  },
  {
    "id": "q293",
    "subject": "FSA",
    "topic": "Financial Analysis Techniques",
    "subtopic": "Industry-specific ratios",
    "difficulty": "HARD",
    "stem": "An analyst compares a grocery chain and a software-as-a-service firm using only inventory turnover and concludes the SaaS firm has superior operating efficiency because it carries almost no inventory. Which critique is strongest?",
    "options": [
      "Inventory turnover is invalid for every company because inventory accounting differs across industries.",
      "Ratio relevance depends on the business model; industry-specific operating drivers should complement generic ratios.",
      "The comparison is valid because the same formula always measures the same economic efficiency across business models."
    ],
    "correct": 1,
    "explanation": "A ratio can be mathematically correct yet economically uninformative across radically different business models. Analysts should select metrics that reflect each industry's drivers and use generic ratios in context. The issue is relevance, not that inventory turnover is universally invalid.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/financial-analysis-techniques"
  },
  {
    "id": "q294",
    "subject": "FSA",
    "topic": "Financial Analysis Techniques",
    "subtopic": "Ratio forecast linkage",
    "difficulty": "EXTREME",
    "stem": "A company's days sales outstanding has risen from 42 to 58 to 71 days while management forecasts revenue growth accelerating and working capital as a constant percentage of sales. Which modeling response is most appropriate?",
    "options": [
      "Set future receivables to zero because DSO is rising.",
      "Keep the constant percentage because historical ratio deterioration never matters to forecasts.",
      "Challenge the constant working-capital assumption and explicitly model collection behavior or a justified normalization path."
    ],
    "correct": 2,
    "explanation": "A persistent trend in collection metrics can materially affect cash needs. A sales-based model should not mechanically assume stable working capital when operating evidence contradicts it. The analyst should model a justified DSO path or explain why normalization is expected.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/financial-analysis-techniques"
  },
  {
    "id": "q295",
    "subject": "FSA",
    "topic": "Introduction to Financial Statement Modeling",
    "subtopic": "Sales-based pro forma",
    "difficulty": "BRUTAL",
    "stem": "A firm's sales are forecast to rise 12%. Receivables and inventory historically scale closely with sales, but long-term debt does not. A junior analyst increases every balance-sheet line by 12%. Which correction is most appropriate?",
    "options": [
      "Forecast operating accounts using their economic drivers and determine financing separately rather than scaling all assets and liabilities mechanically with sales.",
      "Scale debt by 12% because every balance-sheet account must preserve its prior percentage of sales.",
      "Hold all working-capital accounts constant because only the income statement should respond to sales growth."
    ],
    "correct": 0,
    "explanation": "Sales-based models commonly link operating working capital and some operating assets/liabilities to sales or other drivers. Financing items such as debt depend on funding needs and capital-structure assumptions. Uniform scaling confuses operating relationships with financing decisions.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/introduction-to-financial-statement-modeling"
  },
  {
    "id": "q296",
    "subject": "FSA",
    "topic": "Introduction to Financial Statement Modeling",
    "subtopic": "Forecast bias",
    "difficulty": "BRUTAL",
    "stem": "An analyst begins with management's 15% revenue-growth guidance. After industry data weakens materially, she makes only a token reduction because she has spent weeks building the model around 15%. Which bias and remedy best fit?",
    "options": [
      "Anchoring; rebuild key assumptions from independent drivers and use explicit scenarios or base rates.",
      "Availability bias; rely more heavily on the latest management presentation.",
      "Loss aversion; increase the forecast to avoid recognizing a modeling loss."
    ],
    "correct": 0,
    "explanation": "The analyst is anchored to an initial estimate and insufficiently adjusts despite new evidence. Re-deriving the forecast from independent volume/price drivers, peer/industry data and scenarios helps break the anchor. More reliance on management's original number would reinforce the problem.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/introduction-to-financial-statement-modeling"
  },
  {
    "id": "q297",
    "subject": "FSA",
    "topic": "Introduction to Financial Statement Modeling",
    "subtopic": "Porter and margins",
    "difficulty": "EXTREME",
    "stem": "An industry faces low switching costs, transparent pricing, excess capacity, and several similarly sized competitors. A model assumes permanent gross-margin expansion despite no company-specific cost advantage. Which forecast revision is most defensible?",
    "options": [
      "Raise margins further because more competitors increase each firm's pricing power.",
      "Ignore industry structure because Porter analysis cannot affect financial-statement forecasts.",
      "Use the strong rivalry evidence to challenge sustained pricing power and margin expansion unless a credible competitive advantage offsets it."
    ],
    "correct": 2,
    "explanation": "Strong rivalry, low switching costs and excess capacity can constrain price and margins. FSA modeling explicitly links competitive position to prices and costs. Margin expansion could still be valid with differentiation or cost advantage, but the model needs that mechanism rather than an unsupported trend extrapolation.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/introduction-to-financial-statement-modeling"
  },
  {
    "id": "q298",
    "subject": "FSA",
    "topic": "Introduction to Financial Statement Modeling",
    "subtopic": "Inflation forecasting",
    "difficulty": "EXTREME",
    "stem": "A manufacturer can pass only half of input-cost inflation to customers with a six-month lag. Input costs are expected to rise 8% next year, while volume is flat. A model assumes revenue prices and costs both rise 8% immediately, leaving margins unchanged. What is the key flaw?",
    "options": [
      "Inflation should never enter company forecasts because nominal financial statements already contain it.",
      "The model understates margins because any inflation mechanically increases operating leverage.",
      "The model ignores incomplete and delayed pricing pass-through, so it likely overstates near-term margins."
    ],
    "correct": 2,
    "explanation": "Forecasts should distinguish price and volume and model how cost inflation passes through to customer pricing. If only half can be passed through and with delay, costs rise faster than realized prices in the near term, pressuring margin. Equal immediate inflation assumptions erase the economic mechanism.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/introduction-to-financial-statement-modeling"
  },
  {
    "id": "q299",
    "subject": "FSA",
    "topic": "Introduction to Financial Statement Modeling",
    "subtopic": "Forecast horizon",
    "difficulty": "BRUTAL",
    "stem": "An analyst values a company undergoing a three-year plant build followed by a gradual ramp to normal margins. She uses a one-year explicit forecast and then assumes mature steady-state economics from year two onward. Which change most improves the model?",
    "options": [
      "Shorten the explicit horizon further because long forecasts are always less accurate.",
      "Keep the one-year horizon and increase the discount rate enough to compensate for all operating uncertainty.",
      "Extend the explicit horizon through the period in which major operating and investment drivers are converging toward a defensible steady state."
    ],
    "correct": 2,
    "explanation": "The explicit horizon should be long enough to model material transitions before using normalized long-term assumptions. A one-year horizon jumps over construction and ramp economics. Uncertainty does not justify hiding known transitional drivers inside the terminal period or a single discount-rate adjustment.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/introduction-to-financial-statement-modeling"
  },
  {
    "id": "q300",
    "subject": "FSA",
    "topic": "Analyzing Income Statements",
    "subtopic": "Weighted-average shares replacement",
    "difficulty": "EXTREME",
    "stem": "A company begins the year with 12 million common shares, issues 3 million for cash on 1 April, and repurchases 2 million on 1 October. Income available to common shareholders is $39 million. Ignoring stock splits and potential common shares, basic EPS is closest to:",
    "options": [
      "$2.60",
      "$2.84",
      "$3.00"
    ],
    "correct": 1,
    "explanation": "Weighted-average shares = 12×3/12 + 15×6/12 + 13×3/12 = 3 + 7.5 + 3.25 = 13.75 million. Basic EPS = 39/13.75 = approximately $2.84. Using year-end shares gives $3.00; using the largest share count gives $2.60. The timing of issuances and repurchases controls the denominator.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/analyzing-income-statements"
  }
];
