window.EQUITY_QUESTIONS = [
  {
    "id": "q301",
    "subject": "Equity",
    "topic": "Equity Instrument Features",
    "subtopic": "Residual claim",
    "difficulty": "BRUTAL",
    "stem": "A company has $500 million of assets and $380 million of contractual liabilities. A severe downturn reduces asset value by $90 million before any liabilities change. Which investor is most directly exposed to the first loss in residual net asset value?",
    "options": [
      "Senior lenders, because debt holders absorb all asset-value changes before equity.",
      "Common shareholders, because equity is the residual claim after liabilities.",
      "Preferred shareholders only, because common shareholders have a fixed liquidation claim."
    ],
    "correct": 1,
    "explanation": "Common equity is the residual ownership claim. With liabilities contractually senior, declines in asset value initially reduce the residual available to equity. Senior lenders can ultimately suffer if losses exhaust equity and other junior claims, but they do not bear the first residual change simply because assets fall.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/overview-equity-securities"
  },
  {
    "id": "q302",
    "subject": "Equity",
    "topic": "Equity Instrument Features",
    "subtopic": "Cumulative preferred distribution priority",
    "difficulty": "BRUTAL",
    "stem": "A company has 1 million cumulative preferred shares with a $5 annual dividend. It paid no preferred dividend last year and proposes this year to declare $3 million of common dividends after returning to profitability. No preferred dividends have yet been declared this year. Before the proposed common dividend can be paid, which treatment is most consistent with the cumulative preference?",
    "options": [
      "Only the current year’s $5 million preferred dividend matters because last year’s omission permanently disappeared.",
      "The $5 million dividend in arrears must be satisfied, and the current preferred claim must also be addressed according to the issue terms, before a common distribution.",
      "The company must redeem all preferred shares at par because any omitted cumulative dividend automatically triggers liquidation preference."
    ],
    "correct": 1,
    "explanation": "Cumulative preferred dividends that are omitted accumulate as dividends in arrears and have priority over common dividends. Here the missed $5 million from last year does not vanish merely because dividends were not declared then. Before distributing cash to common shareholders, the company must satisfy the accumulated preferred claim and comply with the current-period preferred dividend terms. The strongest distractor treats dividend omission as though it automatically forces redemption; cumulative status creates dividend priority, not an automatic repurchase or liquidation event.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/overview-equity-securities"
  },
  {
    "id": "q303",
    "subject": "Equity",
    "topic": "Equity Instrument Features",
    "subtopic": "Callable versus putable preferred under rate shocks",
    "difficulty": "EXTREME",
    "stem": "Two $100-par preferred shares pay identical fixed dividends. Share C is callable by the issuer at $105; Share P is putable by the investor at $95. Market required returns first fall sharply and later rise sharply, with issuer credit unchanged. Which comparison is most accurate?",
    "options": [
      "C offers the investor more upside when required returns fall because the issuer’s call becomes more valuable to the investor.",
      "P and C should respond identically because option features do not affect preferred-share value until exercised.",
      "C’s upside can be constrained when rates fall, while P’s downside can be supported when rates rise, because the call belongs to the issuer and the put belongs to the investor."
    ],
    "correct": 2,
    "explanation": "Option ownership determines who benefits. When required returns fall, a fixed preferred share would normally appreciate, but the issuer of callable Share C has greater incentive to redeem near the call price, limiting investor upside. When required returns rise, Share P’s investor-held put can support value by providing a contractual exit near $95, subject to the terms. The strongest distractor reverses the beneficiary of the call: an issuer call is valuable to the issuer, not the investor.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/overview-equity-securities"
  },
  {
    "id": "q304",
    "subject": "Equity",
    "topic": "Equity Instrument Features",
    "subtopic": "Public vs private equity",
    "difficulty": "BRUTAL",
    "stem": "An analyst compares a listed manufacturer with a similar privately held manufacturer. The private firm's latest transaction occurred 18 months ago between two founders. Which valuation challenge is most specific to the private security?",
    "options": [
      "Private companies cannot issue multiple classes of equity.",
      "A less observable current market price and typically lower trading liquidity make price discovery more difficult.",
      "Private equity has no residual claim on company assets."
    ],
    "correct": 1,
    "explanation": "Private shares generally lack continuous exchange pricing and active secondary-market liquidity. That makes current price discovery and comparability more difficult. They remain equity residual claims and can have multiple classes; those features do not disappear because the company is private.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q305",
    "subject": "Equity",
    "topic": "Equity Instrument Features",
    "subtopic": "Convertible preferred decision",
    "difficulty": "BRUTAL",
    "stem": "A preferred share has a $100 par value, a fixed dividend, and can be converted at the investor’s option into 4 common shares. The common stock rises to $32, while otherwise comparable non-convertible preferred shares trade near $104. Ignoring transaction costs, which observation is most relevant to the conversion feature?",
    "options": [
      "Conversion guarantees the preferred dividend and therefore makes the $100 par value irrelevant.",
      "Conversion gives the preferred shareholder priority over secured lenders if the common stock later declines.",
      "The conversion value is $128, so the option can allow participation in common-equity upside beyond the value of otherwise similar non-convertible preferred."
    ],
    "correct": 2,
    "explanation": "The conversion value is 4 × $32 = $128. Because the investor controls the conversion option, the feature can become valuable when common-equity value rises sufficiently above the preferred share’s stand-alone value. It does not guarantee dividends and does not alter the preferred claim’s priority relative to secured debt. The decisive step is to translate the conversion ratio into an equity value rather than treating convertibility as merely a label.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/overview-equity-securities"
  },
  {
    "id": "q306",
    "subject": "Equity",
    "topic": "Equity Instrument Features",
    "subtopic": "Book vs market equity",
    "difficulty": "EXTREME",
    "stem": "A profitable software company has book common equity of $300 million and market capitalization of $2.4 billion. A junior analyst concludes that the $2.1 billion difference is an accounting error because “equity should equal equity.” Which response is strongest?",
    "options": [
      "Book equity is the market value of all assets less the market value of all liabilities.",
      "Book equity is an accounting residual, while market capitalization reflects investors' pricing of future cash flows and risks; they need not be equal.",
      "Market capitalization should equal book equity unless the company has preferred stock."
    ],
    "correct": 1,
    "explanation": "Book equity follows accounting recognition and measurement. Market capitalization is current price per share times shares and reflects expectations about future economics, including many intangible sources of value not fully recognized on the balance sheet. A large gap can be economically reasonable and is not itself an error.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/overview-equity-securities"
  },
  {
    "id": "q307",
    "subject": "Equity",
    "topic": "Equity Instrument Features",
    "subtopic": "Investor vs issuer risk",
    "difficulty": "EXTREME",
    "stem": "A company replaces part of its common equity financing with fixed-rate debt. From the company's perspective, contractual payment risk rises; from the common shareholder's perspective, residual earnings become more sensitive to operating results. Which statement is most accurate?",
    "options": [
      "Debt can be riskier to the issuer because payments are contractual, while added leverage can make common equity riskier to investors.",
      "Debt is always less risky for both issuer and investor because it is senior.",
      "Equity is always riskier for the issuer because dividends must be paid before interest."
    ],
    "correct": 0,
    "explanation": "Issuer and investor perspectives differ. Debt creates promised interest and principal payments for the company; common equity has no comparable contractual distribution. For investors, common equity is junior and leverage magnifies residual variability. Seniority alone does not make debt safer for the issuer.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/overview-equity-securities"
  },
  {
    "id": "q308",
    "subject": "Equity",
    "topic": "Equity Instrument Features",
    "subtopic": "Participating preferred economics",
    "difficulty": "BRUTAL",
    "stem": "A $100-par preferred share pays a 6% annual preferred dividend and, after common shareholders receive a specified threshold distribution, also receives an additional share of residual distributions. A junior analyst calls it “non-cumulative preferred” solely because its total cash payout can exceed $6. Which response is most accurate?",
    "options": [
      "The extra distribution right is equivalent to an investor put and therefore makes the share putable common equity.",
      "The issue is participating preferred; participation describes additional upside, while cumulative versus non-cumulative separately describes whether omitted preferred dividends accrue.",
      "Any preferred share that can receive more than its stated dividend loses its preference in liquidation."
    ],
    "correct": 1,
    "explanation": "Participating preferred can receive its stated preference plus specified additional distributions. That feature is distinct from cumulative status, which governs whether omitted preferred dividends accumulate, and from putability, which gives the investor a contractual sale right. The junior analyst is conflating separate dimensions of preferred-share design. Additional participation also does not by itself eliminate liquidation preference.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/overview-equity-securities"
  },
  {
    "id": "q309",
    "subject": "Equity",
    "topic": "Equity Jurisdictions, Classes, and the Voting Process",
    "subtopic": "Dual-class voting",
    "difficulty": "BRUTAL",
    "stem": "A founder owns 12% of a company's economic interest but 55% of voting power through super-voting shares. An analyst assessing governance should most likely conclude that:",
    "options": [
      "economic ownership and control can diverge materially, increasing the importance of class-specific voting rights.",
      "the founder cannot control board elections because ownership is below 50%.",
      "all equity classes must carry voting rights proportional to cash-flow rights."
    ],
    "correct": 0,
    "explanation": "Dual-class structures can separate voting control from economic ownership. A founder can therefore control key votes with a minority of cash-flow rights. Analysts must examine class rights rather than infer control from aggregate economic ownership.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q310",
    "subject": "Equity",
    "topic": "Equity Jurisdictions, Classes, and the Voting Process",
    "subtopic": "Proxy process roles",
    "difficulty": "BRUTAL",
    "stem": "A large asset owner delegates portfolio management to an asset manager. A proxy adviser issues a recommendation on a board election. Who ultimately bears responsibility for how voting rights are exercised under the mandate terms?",
    "options": [
      "The issuer's management, because management prepares the proxy materials.",
      "The proxy adviser, because its recommendation legally transfers voting authority.",
      "The party assigned voting authority by the ownership/management arrangement; the proxy adviser provides analysis rather than owning the vote."
    ],
    "correct": 2,
    "explanation": "Proxy advisers analyze issues and make recommendations, but voting authority remains with the party that holds or has been delegated the voting right under the mandate. Issuer management proposes or communicates matters but does not acquire investors' votes by preparing materials.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q311",
    "subject": "Equity",
    "topic": "Equity Jurisdictions, Classes, and the Voting Process",
    "subtopic": "Economic vs voting rights",
    "difficulty": "EXTREME",
    "stem": "Class A shares receive twice the dividend per share of Class B but have one-tenth the votes. Class B has lower cash-flow rights but much stronger voting rights. Which comparison is most appropriate?",
    "options": [
      "Class A must always trade at exactly twice Class B because its dividend is twice as large.",
      "Neither class is unambiguously superior; value depends on the investor's weighting of economic distributions, control rights, and market pricing.",
      "Class B must always be more valuable because voting rights dominate all cash-flow rights."
    ],
    "correct": 1,
    "explanation": "Different classes bundle economic and control rights differently. Relative market value can reflect both, as well as liquidity and expectations. A fixed price ratio cannot be inferred from current dividend rights alone, and stronger voting rights do not mechanically dominate economic claims.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q312",
    "subject": "Equity",
    "topic": "Equity Jurisdictions, Classes, and the Voting Process",
    "subtopic": "Board election analysis",
    "difficulty": "BRUTAL",
    "stem": "An activist owns 4% of a company and seeks two board seats. Management owns 6%; the remaining shares are widely held by institutions. Which fact is most relevant to predicting the vote outcome?",
    "options": [
      "The board decides the shareholder vote regardless of votes cast.",
      "The activist automatically loses because it owns less than management.",
      "How voting rights are distributed and likely exercised by the institutional asset owners/managers, not merely the activist's ownership percentage."
    ],
    "correct": 2,
    "explanation": "Board elections depend on voting rights and participation across shareholders. A 4% holder can influence outcomes if other holders support it, particularly in dispersed ownership. Comparing activist ownership only with management ownership ignores most votes.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q313",
    "subject": "Equity",
    "topic": "Equity Jurisdictions, Classes, and the Voting Process",
    "subtopic": "Jurisdiction differences",
    "difficulty": "EXTREME",
    "stem": "Two firms have identically labeled “ordinary shares” but are incorporated in different jurisdictions. One jurisdiction allows non-voting ordinary shares; the other generally pairs ordinary shares with votes. Which analytical practice is best?",
    "options": [
      "Assume identical rights because both instruments are called ordinary shares.",
      "Ignore voting rights because jurisdiction never affects equity valuation.",
      "Read the security- and jurisdiction-specific rights rather than infer voting or economic rights from the label alone."
    ],
    "correct": 2,
    "explanation": "Equity rights can differ by jurisdiction and class. Labels are not enough to establish voting, dividend or other ownership rights. Analysts should examine the actual legal and security terms before comparing governance or value.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q314",
    "subject": "Equity",
    "topic": "Equity Jurisdictions, Classes, and the Voting Process",
    "subtopic": "Proxy adviser conflict",
    "difficulty": "EXTREME",
    "stem": "A proxy adviser recommends voting for a transaction while also providing paid consulting to the issuer on governance design. For an asset manager using that recommendation, the most appropriate analytical response is to:",
    "options": [
      "ignore all proxy-adviser research whenever the adviser has any commercial relationship.",
      "follow the recommendation automatically because proxy advisers replace the asset manager's judgment.",
      "consider the adviser's potential conflict and independently evaluate the vote rather than treat the recommendation as dispositive."
    ],
    "correct": 2,
    "explanation": "Proxy advice is an input to the voting process, not a substitute for investor judgment. A commercial relationship can create a conflict that warrants scrutiny. It does not automatically invalidate all analysis, but it reduces the case for mechanical reliance.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q315",
    "subject": "Equity",
    "topic": "Equity Issuance and Trading",
    "subtopic": "Primary versus OTC secondary transactions",
    "difficulty": "BRUTAL",
    "stem": "A company privately places newly issued shares with an institutional investor. Six months later, the investor sells part of that position to a dealer, which resells the shares bilaterally to another investor without using a centralized exchange order book. Which classification is most accurate?",
    "options": [
      "Both transactions are primary-market trades because a dealer participates in the second transaction.",
      "Both transactions are exchange trades because the security itself is publicly registered.",
      "The initial issuance is a primary-market transaction; the later bilateral dealer trade is a secondary off-exchange/OTC transaction."
    ],
    "correct": 2,
    "explanation": "The defining question for a primary market is whether the issuer is creating/selling the security and receiving the financing proceeds. The later sale transfers an existing security between investors; the issuer does not receive the resale proceeds. Because that resale is negotiated through dealers without a centralized exchange order book, it is a secondary OTC/off-exchange trade. Dealer involvement alone does not make a transaction primary.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q316",
    "subject": "Equity",
    "topic": "Equity Issuance and Trading",
    "subtopic": "Float after strategic placement",
    "difficulty": "BRUTAL",
    "stem": "A company has 120 million shares outstanding. Founders own 28 million strategic shares and a government entity owns 12 million restricted strategic shares. The company then issues 15 million new shares entirely to public investors; neither strategic holder sells. Immediately after the issue, public float is closest to:",
    "options": [
      "80 million shares, because newly issued shares do not enter float until an existing holder sells.",
      "95 million shares, because the original 80 million public shares plus 15 million newly issued public shares are freely tradable.",
      "107 million shares, because only the government block should be excluded from float."
    ],
    "correct": 1,
    "explanation": "Before the issue, public float is 120 − 28 − 12 = 80 million shares. The 15 million newly issued shares are sold to public investors and therefore increase both shares outstanding and float, giving 95 million shares of float. Strategic holdings remain excluded. The strongest distractor incorrectly treats founder strategic shares as public float.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q317",
    "subject": "Equity",
    "topic": "Equity Issuance and Trading",
    "subtopic": "Liquidity measures",
    "difficulty": "EXTREME",
    "stem": "Stock A trades $80 million per day with a 4-basis-point bid–ask spread. Stock B trades $20 million per day with a 2-basis-point spread but very shallow quoted depth. For a fund seeking to sell a large block, which conclusion is strongest?",
    "options": [
      "No single measure is sufficient; spread, trading volume, depth and expected price impact all matter for block liquidity.",
      "B is necessarily more liquid because its quoted spread is narrower.",
      "A is necessarily more liquid because ADV alone fully measures liquidity."
    ],
    "correct": 0,
    "explanation": "Liquidity is multidimensional. A narrow displayed spread can coexist with shallow depth and large market impact, while higher volume can support larger trades. A block trader should consider spread, depth, turnover/ADV and expected impact rather than rank securities from one statistic.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q318",
    "subject": "Equity",
    "topic": "Equity Issuance and Trading",
    "subtopic": "Float vs liquidity",
    "difficulty": "BRUTAL",
    "stem": "A company has 500 million shares outstanding but only 70 million in public float because a controlling shareholder holds the rest. Which statement is most defensible?",
    "options": [
      "The small float can constrain tradable supply and may reduce liquidity even though total shares outstanding are large.",
      "Float is irrelevant once a stock is listed on an exchange.",
      "The stock must be highly liquid because shares outstanding exceed 400 million."
    ],
    "correct": 0,
    "explanation": "Tradable supply is better reflected by float than by total shares outstanding when strategic blocks rarely trade. A large total share count therefore does not guarantee deep liquidity.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q319",
    "subject": "Equity",
    "topic": "Equity Issuance and Trading",
    "subtopic": "Price-weighted index and stock splits",
    "difficulty": "EXTREME",
    "stem": "A price-weighted index contains two stocks priced at $200 and $20. The $200 stock executes a 10-for-1 split with no change in company value. The index provider adjusts the divisor appropriately. Immediately after the split, which statement is most accurate?",
    "options": [
      "The index must fall sharply because the sum of component prices falls from the split.",
      "The split increases the high-priced company’s economic market capitalization tenfold and therefore increases its index weight.",
      "The divisor adjustment prevents the split itself from changing the index level, while the stock’s lower post-split price can reduce its subsequent relative influence in a price-weighted index."
    ],
    "correct": 2,
    "explanation": "A stock split changes units rather than company value. A price-weighted index provider adjusts the divisor so that this mechanical price change does not create an artificial index return. After the split, however, the component’s quoted price is much lower, so its weight in a price-weighted methodology can differ from before. The key trap is to confuse a unit change with economic value creation or an index return.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q320",
    "subject": "Equity",
    "topic": "Equity Issuance and Trading",
    "subtopic": "Secondary market supports primary",
    "difficulty": "BRUTAL",
    "stem": "A country has weak secondary-market liquidity for listed shares. A policymaker asks why this can raise companies' cost of raising new equity. The best explanation is:",
    "options": [
      "primary and secondary markets are economically unrelated once an IPO closes.",
      "secondary markets transfer all proceeds directly to issuers, so low trading volume reduces issuer cash each day.",
      "investors may demand a higher expected return for securities that will be difficult or costly to resell, reducing primary-market pricing."
    ],
    "correct": 2,
    "explanation": "Secondary-market liquidity affects investors' willingness to buy new issues and the return they require. Although secondary trades do not deliver proceeds to issuers, a liquid resale market supports primary issuance by improving investor exit and price-discovery conditions.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q321",
    "subject": "Equity",
    "topic": "Equity Issuance and Trading",
    "subtopic": "ADV interpretation",
    "difficulty": "BRUTAL",
    "stem": "A stock's ADV doubles after inclusion in a major index, but its float is unchanged. An analyst says liquidity definitely doubled. Which critique is strongest?",
    "options": [
      "ADV has no relationship to liquidity and should never be used.",
      "Higher ADV is supportive evidence, but liquidity also depends on spreads, depth and price impact; it cannot be inferred one-for-one from ADV.",
      "Float must also double whenever ADV doubles."
    ],
    "correct": 1,
    "explanation": "Trading volume is a useful liquidity measure, but it is not the entire concept. A stock can trade more while still having wide spreads or shallow depth for large orders. Float and ADV measure different things, so one need not move with the other.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q322",
    "subject": "Equity",
    "topic": "Sources of Equity Returns",
    "subtopic": "Price return versus total return",
    "difficulty": "BRUTAL",
    "stem": "An investor buys a stock at $50 immediately after the prior dividend has gone ex-dividend. Over the next year the company pays a $2 dividend, and the stock ends at $54. A colleague reports an 8% “shareholder return” using only the price change. Ignoring taxes and reinvestment, which correction is most accurate?",
    "options": [
      "The colleague is correct because dividends are financing flows and excluded from equity holding-period return.",
      "Price return is 8%, but total shareholder return is 12% because the $2 cash distribution belongs in the holding-period return.",
      "Total return is 4% because dividends must be subtracted from the ending share price."
    ],
    "correct": 1,
    "explanation": "The price return is ($54 − $50)/$50 = 8%. Total return includes distributions received during the holding period: ($54 − $50 + $2)/$50 = 12%. Because the investor bought after the previous dividend had gone ex-dividend and then held through the next dividend, that $2 is part of the investor’s economic return. The strongest distractor confuses corporate financing classification with investor return measurement.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/equity-valuation-concepts-basic-tools"
  },
  {
    "id": "q323",
    "subject": "Equity",
    "topic": "Sources of Equity Returns",
    "subtopic": "Ex-dividend timing and holding-period return",
    "difficulty": "BRUTAL",
    "stem": "An investor buys a share for $80 one trading day before it goes ex-dividend. The declared dividend is $2. On the ex-dividend date the investor sells the share for $78.80. Assuming standard ex-dividend conventions, no taxes, and no other cash flows, which statement is most accurate?",
    "options": [
      "The investor is entitled to the $2 dividend and earns a positive total holding-period return despite the lower sale price.",
      "The buyer loses the dividend because the shares were sold before the payment date, so the holding-period return is negative 1.5%.",
      "The dividend must be split with the purchaser on the ex-dividend date because legal ownership changes before payment."
    ],
    "correct": 0,
    "explanation": "Buying before the ex-dividend date generally gives the investor entitlement to the declared dividend even if the shares are sold on the ex-date. Total wealth received is $78.80 + $2 = $80.80, so the holding-period return is 1.0% ($0.80/$80), ignoring taxes and costs. The payment date is not the decisive ownership cut-off for entitlement; that is the trap in the second answer.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/equity-valuation-concepts-basic-tools"
  },
  {
    "id": "q324",
    "subject": "Equity",
    "topic": "Sources of Equity Returns",
    "subtopic": "Share repurchase economics",
    "difficulty": "EXTREME",
    "stem": "A firm uses excess cash to repurchase shares at a price materially above a well-supported intrinsic value estimate. Operating assets and business outlook are unchanged. For continuing shareholders, the most defensible statement is:",
    "options": [
      "repurchasing materially overvalued shares can transfer value from continuing shareholders to selling shareholders.",
      "repurchases can never affect per-share value because cash and equity both decline.",
      "any repurchase automatically creates value because shares outstanding decline."
    ],
    "correct": 0,
    "explanation": "A repurchase is not value-creating merely because the denominator falls. If the company pays more than intrinsic value, it gives up excessive corporate resources to departing holders. The effect depends on price relative to value and the opportunity cost of cash.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q325",
    "subject": "Equity",
    "topic": "Sources of Equity Returns",
    "subtopic": "Stock split and valuation ratios",
    "difficulty": "BRUTAL",
    "stem": "Immediately before a 3-for-1 stock split, a company trades at $90 per share and reports EPS of $6 on a pre-split share basis. Ignoring market reaction and assuming EPS is restated consistently for the split, which post-split combination is most plausible?",
    "options": [
      "Price about $30, EPS still $6, and P/E falling from 15× to 5× because the split makes the stock cheaper.",
      "Price about $30, EPS about $2, and P/E remaining about 15× because the split changes units rather than underlying value.",
      "Price about $90, EPS about $2, and market capitalization tripling because there are three times as many shares."
    ],
    "correct": 1,
    "explanation": "A 3-for-1 split roughly divides both price per share and per-share accounting quantities such as EPS by three when comparative per-share data are stated consistently. Thus $90 becomes about $30 and $6 EPS becomes about $2; P/E remains 30/2 = 15×. The split does not itself change enterprise economics or market capitalization. Treating the lower nominal price as a lower valuation multiple is the central trap.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/equity-valuation-concepts-basic-tools"
  },
  {
    "id": "q326",
    "subject": "Equity",
    "topic": "Sources of Equity Returns",
    "subtopic": "Reverse split and ownership economics",
    "difficulty": "BRUTAL",
    "stem": "A shareholder owns 2,000 shares of a company with 20 million shares outstanding. The company performs a 1-for-10 reverse split, with no other issuance or repurchase and no market reaction. Which combination is mechanically correct immediately afterward?",
    "options": [
      "The shareholder owns 200 shares but only one-tenth of the prior ownership percentage because fewer shares are held.",
      "The company’s market capitalization rises roughly tenfold because the quoted share price rises roughly tenfold.",
      "The shareholder owns about 200 of 2 million shares, preserving the same ownership percentage while the price per share rises roughly tenfold."
    ],
    "correct": 2,
    "explanation": "Both the investor’s share count and total company shares are divided by ten, so the ownership fraction is unchanged: 2,000/20,000,000 = 200/2,000,000. With no new information, the share price should scale roughly tenfold and market capitalization remain approximately unchanged. The trap is to mistake a change in units for a change in ownership or enterprise value.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/equity-valuation-concepts-basic-tools"
  },
  {
    "id": "q327",
    "subject": "Equity",
    "topic": "Sources of Equity Returns",
    "subtopic": "Dividend vs repurchase",
    "difficulty": "EXTREME",
    "stem": "Two firms distribute the same amount of cash to shareholders. Firm D pays a pro rata dividend; Firm R repurchases shares from willing sellers. Which distinction is most accurate before considering taxes?",
    "options": [
      "Both transactions must have identical per-share effects because the cash amount is identical.",
      "A repurchase is not a shareholder distribution because sellers receive cash from the company.",
      "A dividend distributes cash to all holders per share, while a repurchase reduces shares outstanding and changes which holders remain invested."
    ],
    "correct": 2,
    "explanation": "Both return cash, but the mechanics differ. Dividends are pro rata to current shares; repurchases exchange corporate cash for shares from selling holders and reduce the share count. Price relative to intrinsic value and shareholder participation can therefore matter to continuing holders.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q328",
    "subject": "Equity",
    "topic": "Sources of Equity Returns",
    "subtopic": "Total return with split",
    "difficulty": "EXTREME",
    "stem": "An investor buys one share at $120. During the year the company executes a 2-for-1 split, pays $1.50 per post-split share in dividends, and ends at $64 per post-split share. Ignoring reinvestment, total return is closest to:",
    "options": [
      "4.2%",
      "6.7%",
      "9.2%"
    ],
    "correct": 2,
    "explanation": "After the split the investor owns two shares. Ending value = 2×64 = $128; dividends = 2×1.50 = $3. Total ending wealth = $131. Return = (131−120)/120 = 9.17%. The split itself creates no return; it changes the share count used in the calculation.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q329",
    "subject": "Equity",
    "topic": "Sources of Equity Returns",
    "subtopic": "Repurchase signaling vs value",
    "difficulty": "BRUTAL",
    "stem": "Management announces a repurchase and says the stock is undervalued. Which conclusion is most appropriate for an analyst?",
    "options": [
      "Accept undervaluation as a fact because management would never repurchase overvalued shares.",
      "Treat the announcement as information to investigate, but independently estimate value and assess funding/opportunity cost rather than assume the repurchase proves undervaluation.",
      "Conclude the shares are overvalued because all repurchases reduce book equity."
    ],
    "correct": 1,
    "explanation": "Repurchases can signal management's view, but they can also be motivated by dilution offset, capital structure, compensation or poor capital allocation. Analysts should compare price with independently estimated value and consider how the repurchase is funded.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q330",
    "subject": "Equity",
    "topic": "Introduction to Equity Valuation",
    "subtopic": "Price vs value",
    "difficulty": "BRUTAL",
    "stem": "An analyst estimates intrinsic value at $72 with a reasonable range of $60–$84. The stock trades at $70. Which conclusion is most defensible?",
    "options": [
      "The market price is intrinsic value by definition, so valuation analysis is unnecessary.",
      "The stock is certainly undervalued because $72 exceeds $70.",
      "The point estimate is above price, but model uncertainty may be too large to support a strong undervaluation conclusion."
    ],
    "correct": 2,
    "explanation": "Intrinsic value is an estimate subject to input and model uncertainty. A $2 gap inside a wide reasonable range may not provide a meaningful margin of safety. Market price and value are distinct, but small differences should not be overstated as certainty.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/equity-valuation-concepts-basic-tools"
  },
  {
    "id": "q331",
    "subject": "Equity",
    "topic": "Introduction to Equity Valuation",
    "subtopic": "Enterprise value bridge and non-operating cash",
    "difficulty": "EXTREME",
    "stem": "A company has common equity market capitalization of $900 million, debt of $300 million, preferred stock of $50 million, and $120 million of cash. Analysts estimate that $40 million of the cash is required for normal operations and $80 million is excess cash. If the valuation convention treats only excess cash as a non-operating asset, enterprise value is closest to:",
    "options": [
      "$1.37 billion, because all cash must be added to equity value.",
      "$1.17 billion, because EV ≈ equity value + debt + preferred − excess cash.",
      "$830 million, because all contractual claims are subtracted from common equity value."
    ],
    "correct": 1,
    "explanation": "Using the stated convention, EV = $900m + $300m + $50m − $80m = $1.17bn. The operating cash requirement is left with the operating business rather than deducted as excess cash. This question tests the claim bridge and the analyst’s treatment of non-operating assets, not just memorization of “subtract cash.” Deducting the full $120m would ignore the explicit operating-cash assumption.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q332",
    "subject": "Equity",
    "topic": "Introduction to Equity Valuation",
    "subtopic": "Book value indicator limitation",
    "difficulty": "BRUTAL",
    "stem": "A profitable asset-light platform has minimal book equity because much of its internally created network value is not recognized as an asset. Which valuation conclusion is strongest?",
    "options": [
      "Market capitalization should be replaced with book equity when intangible assets dominate.",
      "Low book equity proves the stock has little intrinsic value.",
      "Book equity may be a weak standalone indicator of intrinsic value for this business, so cash-flow and market-based approaches may deserve more weight."
    ],
    "correct": 2,
    "explanation": "Book value can diverge from economic value when important internally generated intangibles are not recognized. Model selection should reflect company characteristics and available inputs; no single accounting measure becomes intrinsic value by definition.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q333",
    "subject": "Equity",
    "topic": "Introduction to Equity Valuation",
    "subtopic": "Present value model choice",
    "difficulty": "BRUTAL",
    "stem": "A mature utility pays stable dividends broadly aligned with its capacity to distribute cash. A young technology company pays no dividend and reinvests heavily. Which statement is most appropriate?",
    "options": [
      "A dividend model may be more natural for the utility, while a free-cash-flow model may be more informative for the non-dividend payer.",
      "Dividend discount models are always superior because dividends are observable cash.",
      "No present value model can be used for a company that currently pays no dividend."
    ],
    "correct": 0,
    "explanation": "Model choice depends on the economics and available inputs. DDMs are especially intuitive when dividends track distributable capacity; free-cash-flow models can value firms that retain cash rather than distribute it. Lack of a current dividend does not imply zero intrinsic value.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q334",
    "subject": "Equity",
    "topic": "Introduction to Equity Valuation",
    "subtopic": "Asset-based model",
    "difficulty": "EXTREME",
    "stem": "An investment holding company owns separately valued marketable securities and has minimal operating synergies. Which valuation approach may be particularly informative as a cross-check?",
    "options": [
      "A dividend model that ignores the market value of underlying holdings.",
      "A price/sales multiple solely because holding companies have low revenue.",
      "An asset-based approach that values assets and liabilities separately."
    ],
    "correct": 2,
    "explanation": "Asset-based valuation is often useful when assets are separable and their values are observable, such as investment holding entities. It is less naturally suited to businesses whose value is mainly from integrated future operations and intangible competitive advantages.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/equity-valuation-concepts-basic-tools"
  },
  {
    "id": "q335",
    "subject": "Equity",
    "topic": "Introduction to Equity Valuation",
    "subtopic": "Model complexity",
    "difficulty": "EXTREME",
    "stem": "An analyst can fit a 70-input valuation model or a simpler model using the few drivers that explain most economics. The additional 60 inputs are estimated with little evidence. Which choice best follows sound valuation practice?",
    "options": [
      "Prefer the simpler model unless additional complexity is supported by reliable information and materially improves the decision.",
      "Always use the most complex model because more inputs mechanically increase accuracy.",
      "Use no model because all intrinsic-value estimates are uncertain."
    ],
    "correct": 0,
    "explanation": "Valuation is fallible and model choice should match available information. Complexity can create false precision when inputs are weak. Parsimony does not mean ignoring material drivers; it means avoiding unsupported complexity that does not improve the estimate.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/equity-valuation-concepts-basic-tools"
  },
  {
    "id": "q336",
    "subject": "Equity",
    "topic": "Introduction to Equity Valuation",
    "subtopic": "EV vs equity multiple consistency",
    "difficulty": "BRUTAL",
    "stem": "An analyst compares enterprise value with net income across peers and calls the ratio “capital-structure neutral.” What is the strongest critique?",
    "options": [
      "Net income should always be multiplied by debt rather than equity value.",
      "Enterprise value can never be used in a valuation multiple.",
      "The numerator represents value to multiple capital providers while net income is after interest and belongs to common equity, creating a numerator–denominator mismatch."
    ],
    "correct": 2,
    "explanation": "Valuation multiples should pair claims consistently. EV is commonly compared with pre-interest operating measures such as EBITDA, while equity price/value pairs with after-interest measures such as EPS or net income. Mixing EV with net income can distort cross-capital-structure comparisons.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q337",
    "subject": "Equity",
    "topic": "Introduction to Equity Valuation",
    "subtopic": "Price-value decision threshold",
    "difficulty": "HARD",
    "stem": "A stock trades 3% below an analyst's value estimate, but normal estimation error is roughly ±15%. The most appropriate action inference is:",
    "options": [
      "the stock is definitively undervalued because any positive value-price gap is actionable.",
      "the estimated mispricing may be too small relative to uncertainty to justify a strong conclusion.",
      "the stock is definitively overvalued because estimation error exceeds the gap."
    ],
    "correct": 1,
    "explanation": "A valuation difference should be interpreted relative to uncertainty. Small gaps within plausible estimation error often provide weak evidence of mispricing. Uncertainty does not reverse the sign automatically; it reduces confidence in the conclusion.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/equity-valuation-concepts-basic-tools"
  },
  {
    "id": "q338",
    "subject": "Equity",
    "topic": "Discounted Cash Flow (DCF) and Growth Models",
    "subtopic": "Gordon growth using forward dividend",
    "difficulty": "EXTREME",
    "stem": "A mature company has just paid a dividend of $3.00 per share. Dividends are expected to grow 4% indefinitely. The risk-free rate is 3%, the equity risk premium is 5%, and the stock’s beta is 1.2. Using CAPM for the required return and the Gordon growth model, intrinsic value is closest to:",
    "options": [
      "$50.00, using the just-paid dividend and a 6% capitalization spread.",
      "$62.40, using a 5% required return after subtracting beta from the equity risk premium.",
      "$62.40, using next year’s $3.12 dividend and a 9% required return."
    ],
    "correct": 2,
    "explanation": "CAPM gives r = 3% + 1.2×5% = 9%. The Gordon model uses the next dividend, D1 = $3.00×1.04 = $3.12. Therefore V0 = 3.12/(0.09−0.04) = $62.40. The first distractor uses D0 rather than D1, while the second reaches the same number through an invalid required-return logic; the correct method matters even when a distractor is numerically tempting.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/equity-valuation-concepts-basic-tools"
  },
  {
    "id": "q339",
    "subject": "Equity",
    "topic": "Discounted Cash Flow (DCF) and Growth Models",
    "subtopic": "Gordon sensitivity",
    "difficulty": "EXTREME",
    "stem": "Two analysts agree on next year's dividend of $2.00. Analyst A uses r=9% and g=5%; Analyst B uses r=10% and g=6%. Which statement is correct?",
    "options": [
      "B's value is higher because its growth rate is higher.",
      "A's value is higher because its required return is lower.",
      "Both produce the same Gordon value of $50 because each has the same r−g spread of 4%."
    ],
    "correct": 2,
    "explanation": "The Gordon denominator is r−g. Both sets give 4%, so V0=2/0.04=$50. Looking at r or g in isolation is insufficient; their interaction determines value in this setup.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/equity-valuation-concepts-basic-tools"
  },
  {
    "id": "q340",
    "subject": "Equity",
    "topic": "Discounted Cash Flow (DCF) and Growth Models",
    "subtopic": "Invalid constant growth",
    "difficulty": "BRUTAL",
    "stem": "An analyst uses a perpetual-growth DDM with required return 8% and perpetual growth 9%. Which critique is most important?",
    "options": [
      "The model is not economically valid with g at or above r because the constant-growth denominator is non-positive and long-run assumptions are inconsistent.",
      "The only issue is that the stock must be private.",
      "The model is valid as long as next year's dividend is positive."
    ],
    "correct": 0,
    "explanation": "A finite Gordon value requires r > g. A perpetual company growth rate at or above the required return creates mathematical and economic problems. The issue is not listing status or dividend positivity.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/equity-valuation-concepts-basic-tools"
  },
  {
    "id": "q341",
    "subject": "Equity",
    "topic": "Discounted Cash Flow (DCF) and Growth Models",
    "subtopic": "Two-stage DDM",
    "difficulty": "EXTREME",
    "stem": "A stock will pay dividends of $2.00 and $2.40 in years 1 and 2. From year 3 onward dividends grow 4% perpetually. Required return is 10%. Intrinsic value is closest to:",
    "options": [
      "$40.00",
      "$38.18",
      "$35.52"
    ],
    "correct": 1,
    "explanation": "D3 = 2.40×1.04 = 2.496. Terminal value at t=2 = 2.496/(0.10−0.04)=41.60. Present value = 2/1.10 + 2.40/1.10² + 41.60/1.10² ≈ 1.818 + 1.983 + 34.380 = $38.18.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/equity-valuation-concepts-basic-tools"
  },
  {
    "id": "q342",
    "subject": "Equity",
    "topic": "Discounted Cash Flow (DCF) and Growth Models",
    "subtopic": "Preferred required return versus market price",
    "difficulty": "BRUTAL",
    "stem": "A non-callable, non-convertible preferred share pays a fixed $5.40 annual dividend and trades at $54. A comparable preferred issue of similar risk requires a 9% return. Which conclusion is most defensible, assuming the dividend is expected to continue indefinitely?",
    "options": [
      "The indicated value is about $60, so the $54 market price is below the simple perpetuity value if 9% is the appropriate required return.",
      "The indicated value is $49.09 because preferred value is the dividend discounted for exactly one year.",
      "The market price must be fair value by definition, so the comparable required return is irrelevant."
    ],
    "correct": 0,
    "explanation": "For a perpetual fixed preferred dividend, indicated value is D/r = $5.40/0.09 = $60. At a $54 market price, the implied yield is 10%, above the stated 9% comparable required return, so the simple model indicates a lower price than its $60 value estimate. This is still an estimate dependent on risk comparability; the model does not make market price “wrong by definition.”",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/equity-valuation-concepts-basic-tools"
  },
  {
    "id": "q343",
    "subject": "Equity",
    "topic": "Discounted Cash Flow (DCF) and Growth Models",
    "subtopic": "Callable preferred effect",
    "difficulty": "BRUTAL",
    "stem": "Two preferred shares are identical except one is callable by the issuer at a fixed price. If interest rates fall sharply, the callable issue's upside is most likely:",
    "options": [
      "greater because the investor controls the call option.",
      "more limited because the issuer has an incentive to call and refinance.",
      "identical because contingency features cannot affect intrinsic value."
    ],
    "correct": 1,
    "explanation": "The call is an issuer option. Falling required yields would otherwise raise preferred value, but the issuer's ability to redeem at a fixed price can cap that appreciation. The option belongs to the issuer, not the investor.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q344",
    "subject": "Equity",
    "topic": "Discounted Cash Flow (DCF) and Growth Models",
    "subtopic": "FCFE model choice",
    "difficulty": "EXTREME",
    "stem": "A company pays no dividend, but it generates stable positive FCFE and has no near-term plan to initiate a payout. Which statement is strongest?",
    "options": [
      "Only an enterprise-value multiple can value a non-dividend-paying firm.",
      "A present-value model based on FCFE can still estimate common-equity value because value need not depend on current dividend policy.",
      "The equity has zero intrinsic value until a dividend is declared."
    ],
    "correct": 1,
    "explanation": "FCFE represents cash available to common shareholders after operating, investment and financing needs. A company can retain rather than distribute that capacity. Therefore current dividend policy does not make equity intrinsically valueless or prohibit a present-value model.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q345",
    "subject": "Equity",
    "topic": "Discounted Cash Flow (DCF) and Growth Models",
    "subtopic": "FCFF to equity bridge",
    "difficulty": "BRUTAL",
    "stem": "An FCFF model produces enterprise value of $1.8 billion. Debt is $500 million, preferred stock $100 million, and excess cash $80 million was not included in operating FCFF value. Ignoring other claims, common equity value is closest to:",
    "options": [
      "$1.20 billion",
      "$1.28 billion",
      "$2.48 billion"
    ],
    "correct": 1,
    "explanation": "Common equity value = operating enterprise value − debt − preferred + non-operating excess cash = 1.8 − 0.5 − 0.1 + 0.08 = $1.28 billion. The bridge must respect which assets and claims are already included in enterprise value.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q346",
    "subject": "Equity",
    "topic": "Discounted Cash Flow (DCF) and Growth Models",
    "subtopic": "Residual income concept",
    "difficulty": "BRUTAL",
    "stem": "A company earns positive net income but its ROE is persistently below shareholders' required return. Under a residual-income perspective, the company is most likely:",
    "options": [
      "generating zero residual income because residual income applies only to firms with no debt.",
      "generating positive residual income because net income is positive.",
      "generating negative residual income because accounting profit does not cover the equity capital charge."
    ],
    "correct": 2,
    "explanation": "Residual income deducts a charge for the opportunity cost of equity from accounting earnings. Positive net income is not enough: if ROE is below the required return, the firm earns less than the equity capital charge and residual income is negative.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q347",
    "subject": "Equity",
    "topic": "Discounted Cash Flow (DCF) and Growth Models",
    "subtopic": "Residual income with distracting payout data",
    "difficulty": "BRUTAL",
    "stem": "Beginning common book value is $400 million. Expected net income is $48 million, expected common dividends are $12 million, and the required return on equity is 10%. Assuming residual income is measured using beginning book value, expected residual income for the year is:",
    "options": [
      "$40 million, because the equity charge itself is residual income.",
      "$36 million, because dividends must be deducted from net income before the equity charge.",
      "$8 million, because residual income equals $48 million less a $40 million equity capital charge."
    ],
    "correct": 2,
    "explanation": "The equity capital charge is 10% × $400m = $40m. Residual income is expected net income minus that charge: $48m − $40m = $8m. The $12m dividend affects ending book value through clean-surplus mechanics but is not separately deducted from current net income in the residual-income calculation. The strongest distractor confuses distributions with the opportunity cost of equity.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q348",
    "subject": "Equity",
    "topic": "Discounted Cash Flow (DCF) and Growth Models",
    "subtopic": "Model input consistency",
    "difficulty": "EXTREME",
    "stem": "An analyst discounts FCFF at the cost of equity and then subtracts debt to derive common value. What is the central error?",
    "options": [
      "FCFF belongs to all capital providers and should be discounted at an appropriate firm-wide required return, not the common-equity required return alone.",
      "FCFF can only be valued with a price/earnings multiple.",
      "Debt should be added rather than subtracted from enterprise value."
    ],
    "correct": 0,
    "explanation": "The cash-flow claim and discount rate must match. FCFF is before distributions to debt and equity, so it is valued at a rate reflecting the firm's capital providers. FCFE is the flow appropriate to a common-equity required return. Subtracting debt after an inconsistent discount rate does not fix the mismatch.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q349",
    "subject": "Equity",
    "topic": "Discounted Cash Flow (DCF) and Growth Models",
    "subtopic": "Terminal value timing",
    "difficulty": "EXTREME",
    "stem": "A two-stage model forecasts explicit cash flows through year 5 and calculates a Gordon terminal value using year-6 cash flow. At what date is that terminal value located before discounting to today?",
    "options": [
      "At the end of year 5.",
      "At the end of year 6.",
      "At time 0 because it represents all future periods."
    ],
    "correct": 0,
    "explanation": "The Gordon terminal value at the end of explicit year 5 equals CF6/(r−g), representing the value at t=5 of cash flows beginning in year 6. It must then be discounted five periods to time 0. Misplacing the terminal value by one year is a common valuation error.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q350",
    "subject": "Equity",
    "topic": "Discounted Cash Flow (DCF) and Growth Models",
    "subtopic": "Growth transition",
    "difficulty": "BRUTAL",
    "stem": "A small company currently grows dividends 25% annually because it is taking share in a new market. An analyst assumes 25% perpetual growth despite a mature economy and finite market. Which change is most defensible?",
    "options": [
      "Use a multistage model that transitions growth toward a sustainable long-run rate.",
      "Set long-run growth to zero because no company can ever grow perpetually.",
      "Keep 25% forever because historical growth is the most objective input."
    ],
    "correct": 0,
    "explanation": "High current growth can be plausible for a finite period but is rarely sustainable forever. A multistage model can reflect convergence as competition and market saturation change economics. Perpetual growth need not be zero, but it must be economically sustainable relative to the broader system.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q351",
    "subject": "Equity",
    "topic": "Discounted Cash Flow (DCF) and Growth Models",
    "subtopic": "DDM scenario sensitivity",
    "difficulty": "EXTREME",
    "stem": "A stable company has D1=$4, r=9%, g=5%, giving a Gordon value of $100. If r rises by 1 percentage point with g unchanged, value becomes closest to:",
    "options": [
      "$90",
      "$80",
      "$95"
    ],
    "correct": 1,
    "explanation": "New value = 4/(0.10−0.05) = $80. The 1 percentage-point increase in required return reduces value 20% because the r−g spread widens from 4% to 5%. Constant-growth models can be highly sensitive when r and g are close.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/equity-valuation-concepts-basic-tools"
  },
  {
    "id": "q352",
    "subject": "Equity",
    "topic": "Discounted Cash Flow (DCF) and Growth Models",
    "subtopic": "FCFE vs dividends",
    "difficulty": "BRUTAL",
    "stem": "A mature company consistently generates FCFE of $8 per share but pays only $2 in dividends and accumulates excess cash without a clear reinvestment need. Which valuation observation is strongest?",
    "options": [
      "The company must immediately be worth exactly four times the DDM value.",
      "FCFE is irrelevant because only dividends can ever benefit shareholders.",
      "A dividend model may understate distributable capacity if payout policy is not aligned with FCFE; an FCFE model can be a useful cross-check."
    ],
    "correct": 2,
    "explanation": "Dividends are actual distributions; FCFE measures capacity to distribute after necessary investment and financing. If payout persistently differs from capacity, DDM value can depend heavily on assumptions about eventual payout. FCFE provides another lens, but no fixed four-times relation follows.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q353",
    "subject": "Equity",
    "topic": "Discounted Cash Flow (DCF) and Growth Models",
    "subtopic": "Residual income and book value",
    "difficulty": "EXTREME",
    "stem": "Two firms have the same current book value and expected ROE. Firm A has required return 8%; Firm B has required return 12%; expected ROE is 10% for both. Which firm has the more favorable first-year residual-income contribution?",
    "options": [
      "Firm B, because a higher required return always raises residual income.",
      "They are identical because book value and ROE are identical.",
      "Firm A, because ROE exceeds its required return, while Firm B's ROE is below its required return."
    ],
    "correct": 2,
    "explanation": "Residual income depends on earnings relative to the equity charge. At 10% ROE, A earns above its 8% required return and creates positive residual income; B earns below 12% and generates negative residual income. Required return is a cost, not a benefit.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q354",
    "subject": "Equity",
    "topic": "Discounted Cash Flow (DCF) and Growth Models",
    "subtopic": "Stable growth condition",
    "difficulty": "EXTREME",
    "stem": "A model assumes perpetual 4% FCFE growth while also forecasting ROE below the required return forever and no change in financing or payout. Which concern is most important?",
    "options": [
      "ROE and required return are unrelated to valuation once FCFE growth is specified.",
      "Any positive perpetual growth necessarily increases value and proves competitive advantage.",
      "Growth is not automatically value-creating; if incremental investment earns below the required return, more growth can destroy value despite higher cash-flow scale."
    ],
    "correct": 2,
    "explanation": "Growth creates value only when returns on incremental capital exceed the capital's opportunity cost. A forecast can be mathematically consistent yet economically unattractive if reinvestment earns sub-required returns. The analyst should connect growth, investment and returns rather than treat growth as inherently good.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q355",
    "subject": "Equity",
    "topic": "Discounted Cash Flow (DCF) and Growth Models",
    "subtopic": "One-stage vs multistage",
    "difficulty": "HARD",
    "stem": "A regulated utility has stable payout, mature demand, and expected long-run growth near the economy's nominal growth. A single-stage constant-growth model is more defensible than for a startup primarily because:",
    "options": [
      "the utility's cash-flow growth and payout are closer to a stable long-run state.",
      "utilities have no business risk, so required return can be ignored.",
      "startups cannot be valued using present value methods."
    ],
    "correct": 0,
    "explanation": "Constant-growth models are most suitable when fundamentals are already near a sustainable steady state. A startup can still be valued with a multistage present-value model, but imposing stable perpetual inputs immediately is less credible.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q356",
    "subject": "Equity",
    "topic": "Discounted Cash Flow (DCF) and Growth Models",
    "subtopic": "Terminal growth bound",
    "difficulty": "EXTREME",
    "stem": "A mature domestic company has no credible path to gain share indefinitely. An analyst's terminal model assumes the firm grows 3 percentage points faster than the nominal economy forever. Which criticism is strongest?",
    "options": [
      "Terminal growth can exceed the economy indefinitely as long as the discount rate is higher.",
      "Terminal growth must always equal zero for every company.",
      "The assumption can make the firm eventually implausibly large relative to the economy, so terminal growth should be tied to sustainable long-run economics."
    ],
    "correct": 2,
    "explanation": "Mathematical validity (r>g) is not enough. A perpetual growth assumption should also be economically sustainable. A mature firm that outgrows the economy indefinitely without a mechanism for share expansion becomes implausibly dominant. Zero growth is not mandatory, but long-run consistency matters.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q357",
    "subject": "Equity",
    "topic": "Relative Value Equity Valuation Approaches",
    "subtopic": "Forward vs trailing P/E",
    "difficulty": "BRUTAL",
    "stem": "A cyclical company's trailing EPS is $8 at a profit peak, but normalized next-year EPS is forecast at $4. The stock is $80. Which comparison is most accurate?",
    "options": [
      "Trailing P/E is 10× and forward P/E is 20×; the apparently cheap trailing multiple may be distorted by peak earnings.",
      "Trailing P/E is 20× and forward P/E is 10× because forecast earnings are lower.",
      "Both multiples are 10× because the price is unchanged."
    ],
    "correct": 0,
    "explanation": "Trailing P/E=80/8=10×; forward P/E=80/4=20×. A low multiple based on unusually high cyclical earnings can falsely signal cheapness. Analysts must match the earnings period and assess normalization.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q358",
    "subject": "Equity",
    "topic": "Relative Value Equity Valuation Approaches",
    "subtopic": "P/B comparability",
    "difficulty": "EXTREME",
    "stem": "Two firms have the same ROE and growth outlook. Firm A carries large internally generated intangible value off balance sheet; Firm B's comparable intangibles were acquired and recognized. Which relative-valuation concern is strongest?",
    "options": [
      "The acquired intangible should be removed from Firm B's market price before calculating P/B.",
      "P/B may be distorted because book-value recognition differs even if economics are similar.",
      "P/B is always superior to earnings multiples because book value cannot depend on accounting choices."
    ],
    "correct": 1,
    "explanation": "Book value can be affected by recognition differences, especially internally generated versus acquired intangibles. That can make P/B cross-company comparisons misleading without normalization. Market price itself is not adjusted by subtracting an accounting asset.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q359",
    "subject": "Equity",
    "topic": "Relative Value Equity Valuation Approaches",
    "subtopic": "EV/EBITDA consistency",
    "difficulty": "BRUTAL",
    "stem": "Company A has much more debt than Company B but similar operations. Which multiple is generally better designed to reduce the direct effect of capital-structure differences?",
    "options": [
      "EV/EBITDA, because both numerator and denominator are measured before common-equity financing claims.",
      "P/E, because net income is before interest expense.",
      "Price/book, because book equity includes debt."
    ],
    "correct": 0,
    "explanation": "EV measures value to debt and equity capital providers, and EBITDA is before interest, making the pairing less directly sensitive to financing mix than P/E. Net income is after interest; book equity does not include debt as an equity claim.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q360",
    "subject": "Equity",
    "topic": "Relative Value Equity Valuation Approaches",
    "subtopic": "Negative earnings",
    "difficulty": "BRUTAL",
    "stem": "A profitable-on-cash-flow startup reports negative EPS because of large noncash expenses. Which valuation observation is most appropriate?",
    "options": [
      "Negative EPS means the equity must have zero intrinsic value.",
      "P/E is not economically meaningful with negative earnings, so other appropriate multiples or present-value methods may be more informative.",
      "A negative P/E should be ranked as cheaper than any positive P/E."
    ],
    "correct": 1,
    "explanation": "A negative earnings denominator makes P/E difficult to interpret as a conventional valuation multiple. Analysts may use sales, cash-flow or enterprise-value measures if economically appropriate, or a DCF. Negative accounting earnings do not imply zero value.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q361",
    "subject": "Equity",
    "topic": "Relative Value Equity Valuation Approaches",
    "subtopic": "Peer selection",
    "difficulty": "EXTREME",
    "stem": "A cloud-software company is legally classified in “technology services,” but its economics depend on subscription retention, gross margin and sales efficiency. A potential peer in another classification has nearly identical drivers. Which peer approach is strongest?",
    "options": [
      "Use industry classification as a starting point but include firms with similar economic drivers of expected return when that improves comparability.",
      "Exclude the economically similar firm because peer groups must never cross classification codes.",
      "Choose peers only by market capitalization because size dominates business economics."
    ],
    "correct": 0,
    "explanation": "The 2027 LOS explicitly allows peer selection based on industry classification or specific drivers of expected return. Classification is useful but imperfect, especially for diversified or novel business models. Economic comparability can justify crossing a code boundary.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q362",
    "subject": "Equity",
    "topic": "Relative Value Equity Valuation Approaches",
    "subtopic": "Comparable multiple adjustment",
    "difficulty": "BRUTAL",
    "stem": "A company trades at 18× forward earnings versus peers at 14×. It also has materially higher expected growth, stronger margins and lower risk. Which conclusion is most defensible?",
    "options": [
      "The premium multiple may be justified by fundamentals; the raw peer median alone does not prove overvaluation.",
      "Growth, profitability and risk cannot affect a justified multiple.",
      "The stock is necessarily 22% overvalued because 18× exceeds 14×."
    ],
    "correct": 0,
    "explanation": "Multiples reflect expected fundamentals. Higher sustainable growth and profitability and lower risk can support a premium. Relative valuation requires understanding why multiples differ, not merely ranking them against a median.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q363",
    "subject": "Equity",
    "topic": "Relative Value Equity Valuation Approaches",
    "subtopic": "Justified P/E fundamentals",
    "difficulty": "EXTREME",
    "stem": "Two stable firms have the same payout ratio and required return. Firm A has a higher sustainable growth rate than Firm B, with growth still below the required return. Under a Gordon-style justified P/E relationship, Firm A should generally have:",
    "options": [
      "a lower justified P/E because growth always requires reinvestment.",
      "the same justified P/E because payout and required return are identical.",
      "a higher justified P/E because the r−g denominator is smaller."
    ],
    "correct": 2,
    "explanation": "For a stable dividend framework, justified leading P/E is related to payout/(r−g). Holding payout and r constant, a higher sustainable g reduces the denominator and raises the multiple. The growth assumption must remain economically defensible.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q364",
    "subject": "Equity",
    "topic": "Relative Value Equity Valuation Approaches",
    "subtopic": "P/S margin trap",
    "difficulty": "BRUTAL",
    "stem": "Two retailers trade at the same P/S multiple. Retailer A has an 8% sustainable net margin; Retailer B has 2%, with similar growth and risk. Which inference is strongest?",
    "options": [
      "The same P/S does not imply equal valuation attractiveness because each dollar of A's sales converts to much more earnings.",
      "B is necessarily cheaper because lower margins reduce the denominator of P/S.",
      "P/S fully controls for profitability, so the firms are equally valued."
    ],
    "correct": 0,
    "explanation": "Sales multiples ignore profitability directly. Firms with different margins can deserve different P/S ratios. A raw equal P/S comparison can therefore hide major differences in earnings power.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q365",
    "subject": "Equity",
    "topic": "Relative Value Equity Valuation Approaches",
    "subtopic": "Normalized EV multiple to equity value",
    "difficulty": "EXTREME",
    "stem": "A peer median EV/EBITDA multiple is 9×. The subject company reports EBITDA of $120 million, including a $20 million non-recurring gain from selling an operating permit that peers do not include in EBITDA. Debt is $250 million and excess cash is $70 million. Using normalized EBITDA and no other adjustments, common equity value is closest to:",
    "options": [
      "$720 million",
      "$900 million",
      "$1.220 billion"
    ],
    "correct": 0,
    "explanation": "Normalize EBITDA first: $120m − $20m = $100m. Applying 9× gives enterprise value of $900m. Bridge to common equity: $900m − $250m debt + $70m excess cash = $720m. Using reported EBITDA would embed a non-comparable one-off gain in the denominator and overstate both enterprise and equity value. The sequence—normalize, apply an EV multiple, then bridge claims—is the controlling logic.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q366",
    "subject": "Equity",
    "topic": "Relative Value Equity Valuation Approaches",
    "subtopic": "Past vs forward multiples",
    "difficulty": "EXTREME",
    "stem": "A company just completed a major capacity expansion. Historical EBITDA excludes nearly all expected new output, while next year's forecast includes the ramp. Which multiple comparison is most useful if the forecast is credible?",
    "options": [
      "A forward EV/EBITDA can better align current enterprise value with expected post-expansion earnings, while the forecast uncertainty should be assessed.",
      "Forward multiples are invalid because valuation cannot use estimates.",
      "Historical EV/EBITDA must always be superior because realized data can never be stale economically."
    ],
    "correct": 0,
    "explanation": "Current value reflects future expectations, so forward fundamentals can be more decision-relevant after a structural change. But forecast multiples embed estimation risk and should be tested. Historical data are observable, not automatically representative.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q367",
    "subject": "Equity",
    "topic": "Relative Value Equity Valuation Approaches",
    "subtopic": "Different accounting policies",
    "difficulty": "BRUTAL",
    "stem": "Two peers use different accounting policies that materially affect reported earnings but not cash economics. An analyst compares P/E without adjustment. The main problem is:",
    "options": [
      "market prices must be restated under the same accounting policy.",
      "the denominator may not be comparable, so the multiple difference can reflect accounting rather than valuation.",
      "P/E is immune to accounting differences because price is market determined."
    ],
    "correct": 1,
    "explanation": "A market-determined numerator does not make the accounting denominator comparable. When policies shift earnings timing or measurement, analysts may need normalization or a different metric before interpreting relative P/E.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q368",
    "subject": "Equity",
    "topic": "Relative Value Equity Valuation Approaches",
    "subtopic": "EV and excess cash",
    "difficulty": "BRUTAL",
    "stem": "Two firms have identical operating businesses and debt, but Firm A holds substantial excess cash. If both trade at the same enterprise value, Firm A's equity market capitalization should be, all else equal:",
    "options": [
      "higher, because equity value includes the excess cash after accounting for debt.",
      "identical, because cash can never affect equity value.",
      "lower, because enterprise value already adds cash."
    ],
    "correct": 0,
    "explanation": "A common bridge is EV = equity value + debt − excess cash (plus other claims as relevant). Holding EV and debt constant, more excess cash implies higher equity value. Cash is subtracted in computing EV precisely because it is a non-operating asset available to equity/capital providers.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q369",
    "subject": "Equity",
    "topic": "Relative Value Equity Valuation Approaches",
    "subtopic": "Multiple outlier",
    "difficulty": "EXTREME",
    "stem": "A stock trades at half the peer P/E. Its earnings include a large asset-sale gain that will not recur, while peers' earnings are normalized. Which adjustment is most important?",
    "options": [
      "Use the reported P/E because market multiples should never adjust accounting earnings.",
      "Normalize the subject company's earnings before concluding the lower P/E represents undervaluation.",
      "Double the stock price because its P/E is half the peer multiple."
    ],
    "correct": 1,
    "explanation": "A one-off gain inflates the denominator and mechanically depresses P/E. Relative valuation requires comparable, sustainable fundamentals. Applying a peer multiple to unnormalized earnings can create a false cheapness signal.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q370",
    "subject": "Equity",
    "topic": "Relative Value Equity Valuation Approaches",
    "subtopic": "Forecasted fundamentals method",
    "difficulty": "EXTREME",
    "stem": "A stock trades at a premium P/E despite being in the same industry as peers. An analyst wants to determine whether the premium is justified rather than merely observable. Which method is most aligned with that question?",
    "options": [
      "Use book value alone because fundamentals cannot justify market multiples.",
      "Use only the peer median and assume any premium is mispricing.",
      "Relate the multiple to forecasted fundamentals such as growth, payout, profitability and required return."
    ],
    "correct": 2,
    "explanation": "The method of forecasted fundamentals explains a justified multiple from expected economic drivers. Comparables show how the market prices peers, but a premium can be rational if the company's growth, profitability, payout or risk differ materially.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q371",
    "subject": "Equity",
    "topic": "Financial Statement Forecasting in Equity Valuation",
    "subtopic": "Disaggregated forecast",
    "difficulty": "BRUTAL",
    "stem": "A 2027 equity model forecasts revenue growth at 12% and simply assumes every expense, working-capital account, capex and debt balance also grows 12%. Which improvement is most consistent with the updated curriculum?",
    "options": [
      "Use fewer financial statements and forecast only EPS because valuation depends only on earnings.",
      "Forecast revenue, margins, investment and financing using separate economic drivers instead of a single proportional growth rate.",
      "Keep all items proportional to revenue because disaggregation adds no information."
    ],
    "correct": 1,
    "explanation": "The 2027 Equity revision explicitly grounds valuation in disaggregated financial-statement forecasting. Revenue, margins, investment and financing can follow different drivers; forcing all lines to one growth rate can hide capital intensity, working-capital needs and financing changes.",
    "source": "https://www.cfainstitute.org/sites/default/files/curriculum-update-2027.pdf"
  },
  {
    "id": "q372",
    "subject": "Equity",
    "topic": "Financial Statement Forecasting in Equity Valuation",
    "subtopic": "Revenue drivers",
    "difficulty": "EXTREME",
    "stem": "An airline's revenue equals passengers × average fare. A model assumes 15% revenue growth but industry seat capacity is expected to rise 2%, load factor is already near a practical ceiling, and pricing is expected to rise 3%. Which response is strongest?",
    "options": [
      "The 15% revenue forecast lacks a clear volume/price mechanism and should be rebuilt from capacity, load factor and fare assumptions.",
      "Set revenue growth to exactly 2% because price never affects airline revenue.",
      "Keep 15% because top-line growth can be forecast independently of operational drivers."
    ],
    "correct": 0,
    "explanation": "Disaggregated forecasting connects revenue to operational drivers. With modest capacity and pricing growth and little load-factor headroom, 15% requires an additional mechanism such as acquisitions or mix. Neither a top-down unsupported number nor capacity alone captures the economics.",
    "source": "https://www.cfainstitute.org/sites/default/files/curriculum-update-2027.pdf"
  },
  {
    "id": "q373",
    "subject": "Equity",
    "topic": "Financial Statement Forecasting in Equity Valuation",
    "subtopic": "Margin forecast",
    "difficulty": "BRUTAL",
    "stem": "A consumer company is losing pricing power while commodity input costs are rising. An analyst forecasts flat gross margin because “revenue and costs should both inflate.” What is the key issue?",
    "options": [
      "The forecast should model pass-through ability and timing; weak pricing power can make costs rise faster than realized prices and compress margins.",
      "Inflation can never affect gross margin.",
      "Gross margin must expand whenever nominal revenue grows."
    ],
    "correct": 0,
    "explanation": "Margins depend on relative price and cost movement, not inflation alone. If a company cannot pass through input inflation fully or quickly, gross margin can fall. The valuation model should connect competitive position to revenue and cost assumptions.",
    "source": "https://www.cfainstitute.org/sites/default/files/curriculum-update-2027.pdf"
  },
  {
    "id": "q374",
    "subject": "Equity",
    "topic": "Financial Statement Forecasting in Equity Valuation",
    "subtopic": "Investment requirements",
    "difficulty": "EXTREME",
    "stem": "Two analysts forecast the same revenue and operating margin for a semiconductor firm. Analyst A assumes capex remains 6% of sales; Analyst B assumes 14% because the forecast requires a new fabrication facility. All else equal, whose equity value is likely lower and why?",
    "options": [
      "Values must be identical because operating margin is the same.",
      "B's, because higher required investment reduces free cash flow even with identical accounting operating margins.",
      "A's, because lower capex automatically lowers revenue."
    ],
    "correct": 1,
    "explanation": "Equity valuation depends on cash generated after necessary investment, not operating margin alone. If the growth plan requires materially more capital investment, free cash flow is lower unless offset elsewhere. The 2027 framework explicitly separates margin and investment assumptions.",
    "source": "https://www.cfainstitute.org/sites/default/files/curriculum-update-2027.pdf"
  },
  {
    "id": "q375",
    "subject": "Equity",
    "topic": "Financial Statement Forecasting in Equity Valuation",
    "subtopic": "Financing forecast",
    "difficulty": "EXTREME",
    "stem": "A model projects aggressive expansion and negative FCFE for three years but holds debt and share count unchanged and never allows cash to fall below zero. Which construction flaw is most important?",
    "options": [
      "The model lacks a financing mechanism to fund the projected cash deficit, making the statements internally inconsistent.",
      "Negative FCFE automatically means the company has zero equity value.",
      "Debt and equity financing should never be forecast in an equity model."
    ],
    "correct": 0,
    "explanation": "A linked forecast must reconcile funding needs. If operations and investment consume more cash than available, the company needs borrowing, equity issuance, asset sales or reduced spending. Holding all financing variables fixed while preventing negative cash creates an impossible balance sheet.",
    "source": "https://www.cfainstitute.org/sites/default/files/curriculum-update-2027.pdf"
  },
  {
    "id": "q376",
    "subject": "Equity",
    "topic": "Financial Statement Forecasting in Equity Valuation",
    "subtopic": "Probability-weighted scenarios and market price",
    "difficulty": "BRUTAL",
    "stem": "An analyst estimates equity values of $40, $70 and $110 under bear, base and bull scenarios with probabilities of 25%, 50% and 25%. The stock trades at $75. Ignoring risk adjustments beyond those embedded in the scenario values, which statement is most accurate?",
    "options": [
      "The probability-weighted value is $73.33, so the stock is slightly undervalued.",
      "The correct value is the $70 base case because scenario probabilities should not affect valuation.",
      "The probability-weighted value is $72.50, which is below the $75 market price; the bull case alone does not establish undervaluation."
    ],
    "correct": 2,
    "explanation": "Probability-weighted value = 0.25×$40 + 0.50×$70 + 0.25×$110 = $72.50. On the stated assumptions, that is below the $75 price. A simple average would be $73.33 and ignores the assigned probabilities; using only the base case ignores the information in the tails. The more important analytical point is that an attractive upside scenario does not by itself establish expected undervaluation.",
    "source": "https://www.cfainstitute.org/sites/default/files/curriculum-update-2027.pdf"
  },
  {
    "id": "q377",
    "subject": "Equity",
    "topic": "Financial Statement Forecasting in Equity Valuation",
    "subtopic": "Scenario dependence",
    "difficulty": "EXTREME",
    "stem": "A model uses a recession scenario but lowers revenue growth while leaving margins, working capital, capex, credit spreads and financing unchanged from the bull case. Which critique is strongest?",
    "options": [
      "Every scenario should differ in exactly one variable to preserve mathematical purity.",
      "Scenario analysis is invalid because intrinsic value must be a single point estimate.",
      "Scenario assumptions should be economically coherent across linked drivers; changing only revenue can understate second-order effects."
    ],
    "correct": 2,
    "explanation": "Probability-weighted scenarios are useful when each scenario tells a coherent economic story. A recession can affect pricing, utilization, margins, working capital, financing and investment. Holding all those constant can create an internally inconsistent downside case.",
    "source": "https://www.cfainstitute.org/sites/default/files/curriculum-update-2027.pdf"
  },
  {
    "id": "q378",
    "subject": "Equity",
    "topic": "Financial Statement Forecasting in Equity Valuation",
    "subtopic": "Subject company characteristics",
    "difficulty": "BRUTAL",
    "stem": "A bank, a regulated utility and a software subscription company are all valued with an identical forecast template focused on EBITDA margin and capex/sales. Which statement is strongest?",
    "options": [
      "Only industry classification matters; company-specific economics should not alter model construction.",
      "The model structure should reflect company characteristics and the economic drivers relevant to each business rather than force a universal template.",
      "A universal template is preferable because comparability always requires identical drivers."
    ],
    "correct": 1,
    "explanation": "The 2027 LOS asks candidates to evaluate model construction based on subject-company characteristics. Different business models have different balance-sheet, revenue, capital and regulatory drivers. Standardization can help comparison but should not override economics.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q379",
    "subject": "Equity",
    "topic": "Financial Statement Forecasting in Equity Valuation",
    "subtopic": "Value from model outputs",
    "difficulty": "EXTREME",
    "stem": "A forecast model produces rapidly growing earnings but even faster working-capital and capital-investment needs, causing FCFE to stay near zero for years. Which interpretation is most appropriate?",
    "options": [
      "The high earnings growth guarantees a high DCF value regardless of free cash flow.",
      "Working capital and capex are balance-sheet items and therefore irrelevant to equity valuation.",
      "Earnings growth alone does not establish high equity value; the cash investment required to support growth must be incorporated into valuation."
    ],
    "correct": 2,
    "explanation": "Valuation connects operating forecasts to cash available to investors. Growth that absorbs large working capital and capex may create less free cash flow than the income statement suggests. The model must capture both profitability and reinvestment.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q380",
    "subject": "Equity",
    "topic": "Financial Statement Forecasting in Equity Valuation",
    "subtopic": "Scenario probability discipline",
    "difficulty": "EXTREME",
    "stem": "An analyst sets a 70% probability on the bull case because she “likes management,” 25% on base and 5% on bear, without evidence. What is the most important improvement?",
    "options": [
      "Set all scenarios to 33.3% because equal probabilities are always objective.",
      "Ground scenario probabilities in observable evidence, base rates and explicit assumptions rather than using probabilities as disguised conviction.",
      "Remove the bear case because probabilities should sum to less than 100% when uncertainty is high."
    ],
    "correct": 1,
    "explanation": "Probability weighting is only as useful as the reasoning behind the probabilities. They should reflect evidence and uncertainty, not serve as an arbitrary mechanism to force a preferred value. Equal weighting can also be unjustified; the goal is calibrated, explainable probabilities.",
    "source": "https://www.cfainstitute.org/sites/default/files/curriculum-update-2027.pdf"
  },
  {
    "id": "q381",
    "subject": "Equity",
    "topic": "Industry and Competitive Analysis",
    "subtopic": "Porter supplier power with competing facts",
    "difficulty": "EXTREME",
    "stem": "A medical-device industry depends on a patented sensor supplied by only two vendors. Switching sensors requires a year of regulatory reapproval. The sensor is only 4% of the device’s selling price, but device makers cannot sell without it. Which conclusion about supplier power is most defensible?",
    "options": [
      "Supplier power is weak because the sensor represents a small percentage of the final product price.",
      "Supplier power is likely strong because concentration, differentiation and very high switching costs can dominate the small cost share.",
      "Supplier power is irrelevant because only end customers affect an industry’s profitability."
    ],
    "correct": 1,
    "explanation": "Porter analysis weighs the structure of the bargaining relationship, not one statistic. Two concentrated suppliers control a patented, essential input, and switching requires costly regulatory reapproval. Those facts create strong supplier leverage. The sensor’s small share of the final product price can actually make buyers less willing to risk disruption over a price increase. The strongest distractor focuses on cost share while ignoring dependence and switching barriers.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/industry-and-competitive-analysis"
  },
  {
    "id": "q382",
    "subject": "Equity",
    "topic": "Industry and Competitive Analysis",
    "subtopic": "Porter buyer power with offsetting differentiation",
    "difficulty": "EXTREME",
    "stem": "Three customers account for 80% of purchases from a component industry, which points to strong buyer power. However, one supplier owns a patented design that reduces each customer’s total manufacturing cost by 15%, and switching away would require a two-year product redesign. Relative to the rest of the industry, that supplier is most likely:",
    "options": [
      "better protected from buyer power because differentiation and switching costs weaken customers’ bargaining leverage despite buyer concentration.",
      "equally exposed because customer concentration mechanically determines buyer power regardless of switching costs or differentiation.",
      "more exposed because a valuable patented design always makes backward integration easier for buyers."
    ],
    "correct": 0,
    "explanation": "Buyer concentration is an important source of bargaining power, but it is not the only one. For this specific supplier, differentiated economic value and very high switching costs reduce customers’ credible alternatives and therefore offset some of their concentration-based leverage. The second answer is too mechanical; Porter analysis requires combining the relevant structural facts rather than treating one force determinant as dispositive.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/industry-and-competitive-analysis"
  },
  {
    "id": "q383",
    "subject": "Equity",
    "topic": "Industry and Competitive Analysis",
    "subtopic": "Threat of entry",
    "difficulty": "EXTREME",
    "stem": "An industry has high historical margins, but entry requires minimal capital, customers have no switching costs, technology is widely available, and incumbents lack scale advantages. Which forecast implication is strongest?",
    "options": [
      "High margins prove the industry has durable entry barriers.",
      "Low capital requirements reduce threat of entry because new firms need less financing.",
      "High current margins may attract entry and be difficult to sustain absent a new barrier or differentiation."
    ],
    "correct": 2,
    "explanation": "The listed conditions all lower entry barriers. Attractive margins can invite new competitors, which can pressure price and returns. Historical profitability therefore should not be extrapolated without a mechanism that protects incumbents.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/industry-and-competitive-analysis"
  },
  {
    "id": "q384",
    "subject": "Equity",
    "topic": "Industry and Competitive Analysis",
    "subtopic": "PESTLE vs Porter",
    "difficulty": "BRUTAL",
    "stem": "A government proposes emissions rules that could force all cement producers to install expensive equipment. Which framework most directly captures the regulatory change itself, and which analysis captures how it may alter rivalry and entry economics?",
    "options": [
      "Neither framework can connect external regulation to valuation assumptions.",
      "Porter identifies the legal rule, while PESTLE is used only for company financial ratios.",
      "PESTLE identifies the political/legal external change; Porter analysis can evaluate its effects on industry structure and competitive forces."
    ],
    "correct": 2,
    "explanation": "PESTLE organizes external political, economic, social, technological, legal and environmental influences. Porter examines structural competitive forces. A regulation can enter through PESTLE and then change barriers, costs or rivalry analyzed through Porter, ultimately affecting valuation drivers.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/industry-and-competitive-analysis"
  },
  {
    "id": "q385",
    "subject": "Equity",
    "topic": "Industry and Competitive Analysis",
    "subtopic": "Industry definition",
    "difficulty": "EXTREME",
    "stem": "A diversified company sells payment software, consumer lending and cloud services. A classification provider assigns it to “financial services.” For competitive analysis, the most appropriate approach is to:",
    "options": [
      "define relevant competitive arenas by actual products/customers and use classifications as a starting point rather than force all economics into one label.",
      "accept the single classification as the complete industry definition.",
      "exclude the company from industry analysis because diversified firms cannot be classified."
    ],
    "correct": 0,
    "explanation": "Industry boundaries can be difficult when companies span multiple businesses. Third-party classifications are useful but have limitations. Analysts should identify the competitive sets that drive each material segment rather than assume one label captures all economics.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/industry-and-competitive-analysis"
  },
  {
    "id": "q386",
    "subject": "Equity",
    "topic": "Industry and Competitive Analysis",
    "subtopic": "Market-share inference from volume and price",
    "difficulty": "BRUTAL",
    "stem": "Industry revenue grows 6%, consisting approximately of 2% average price growth and 4% unit growth. Company A’s revenue grows 15%, with 8% average price/mix growth and no acquisition. Its unit volume therefore grows roughly 6.5%. Which inference is most defensible, assuming consistent market definitions?",
    "options": [
      "A is probably gaining unit market share because its approximate 6.5% volume growth exceeds the industry’s 4%, although mix and measurement should still be checked.",
      "A must be losing share because most of its revenue growth came from price/mix rather than volume.",
      "A’s share is necessarily unchanged because both company and industry revenue growth are positive."
    ],
    "correct": 0,
    "explanation": "Approximate company volume growth is 1.15/1.08 − 1 ≈ 6.5%, which exceeds the industry’s roughly 4% unit growth. With consistent definitions and no acquisition, that supports a market-share gain. The conclusion is still approximate because price/mix and market definitions can differ. Looking only at the 15% headline revenue growth would be weaker; decomposing price and volume is the decisive step.",
    "source": "https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/industry-and-competitive-analysis"
  },
  {
    "id": "q387",
    "subject": "Equity",
    "topic": "Industry and Competitive Analysis",
    "subtopic": "External force to valuation",
    "difficulty": "EXTREME",
    "stem": "A new technology sharply lowers customers' cost of switching among telecom providers. An analyst leaves churn, pricing and required marketing spending unchanged. Which valuation link is most clearly missing?",
    "options": [
      "Lower switching costs can intensify rivalry and buyer power, potentially raising churn/marketing costs and reducing pricing power and margins.",
      "Lower switching costs mechanically reduce the risk-free rate.",
      "Porter analysis should remain separate from financial forecasts to avoid double counting."
    ],
    "correct": 0,
    "explanation": "The 2027 Equity curriculum explicitly links competitive frameworks to valuation narratives. Lower switching costs can weaken customer lock-in, affect price, churn and acquisition spending, and therefore change revenue and margin forecasts. The impact is operating, not a mechanical change in the risk-free rate.",
    "source": "https://www.cfainstitute.org/sites/default/files/curriculum-update-2027.pdf"
  },
  {
    "id": "q388",
    "subject": "Equity",
    "topic": "Company Analysis: Past, Present, and Future",
    "subtopic": "Revenue drivers",
    "difficulty": "BRUTAL",
    "stem": "A subscription company reports 20% revenue growth. Customer count rises 5%, average revenue per customer rises 4%, and an acquisition accounts for the rest. Management describes all 20% as “organic momentum.” Which response is strongest?",
    "options": [
      "Exclude pricing from revenue analysis because only customer count is operational.",
      "Use 20% as organic growth because total reported revenue is the only relevant driver.",
      "Disaggregate customer, pricing/mix and acquisition effects before forecasting organic revenue growth."
    ],
    "correct": 2,
    "explanation": "Company analysis should identify the mechanisms driving revenue. Customer count and revenue per customer explain only part of total growth; acquisition contribution is economically different from organic expansion. Forecasting should separate these components.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q389",
    "subject": "Equity",
    "topic": "Company Analysis: Past, Present, and Future",
    "subtopic": "Pricing power",
    "difficulty": "EXTREME",
    "stem": "A branded consumer company raises price 8%; unit volume falls only 1% while competitors also raise prices 4%. Input costs are flat. Which observation most strongly supports company-specific pricing power?",
    "options": [
      "Revenue rises after any price increase, which always proves pricing power.",
      "The company's price increase materially exceeds peers' while volume is nearly retained.",
      "Flat input costs prove customers have no alternatives."
    ],
    "correct": 1,
    "explanation": "Pricing power is the ability to raise realized prices without losing disproportionate volume or economics. Outpricing peers by four points with only a 1% volume decline is stronger evidence than revenue growth alone. Flat input costs do not establish customer alternatives.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q390",
    "subject": "Equity",
    "topic": "Company Analysis: Past, Present, and Future",
    "subtopic": "Working capital and growth",
    "difficulty": "BRUTAL",
    "stem": "Two firms have the same revenue and margin growth. Firm A requires 5 cents of additional net working capital per incremental dollar of sales; Firm B requires 20 cents. All else equal, which has better cash conversion from growth?",
    "options": [
      "Firm A, because less incremental cash is tied up in working capital for each dollar of growth.",
      "They are identical because working capital affects the balance sheet but not cash flow.",
      "Firm B, because higher working capital automatically means higher value."
    ],
    "correct": 0,
    "explanation": "Growth can consume cash through receivables and inventory net of operating liabilities. Lower incremental working-capital needs generally leave more free cash flow for the same operating growth, all else equal.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q391",
    "subject": "Equity",
    "topic": "Company Analysis: Past, Present, and Future",
    "subtopic": "Capital structure resilience",
    "difficulty": "EXTREME",
    "stem": "Two cyclical companies have similar operating margins. Company X has net cash; Company Y has high debt and a large maturity next year. In a recession scenario, which valuation difference is most important?",
    "options": [
      "Y faces greater financing and equity-downside risk because fixed claims can amplify a decline in enterprise value and constrain flexibility.",
      "Capital structure is irrelevant once operating margins are equal.",
      "X must have lower equity value because holding cash always destroys value."
    ],
    "correct": 0,
    "explanation": "Company analysis includes capital structure because equity is residual. High fixed claims and near-term refinancing needs can magnify downside to common holders and reduce strategic flexibility. Similar current operating margins do not equal similar equity risk.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q392",
    "subject": "Equity",
    "topic": "Equity Analyst Research Reports",
    "subtopic": "Report completeness",
    "difficulty": "BRUTAL",
    "stem": "A report gives a target price and “Buy” rating but contains no investment thesis, valuation method, key assumptions, catalysts or risks. Which critique is strongest?",
    "options": [
      "Research reports should avoid discussing risks because they weaken the recommendation.",
      "A target price alone is sufficient if the analyst has a strong reputation.",
      "The conclusion is difficult to evaluate because a detailed research report should communicate the analysis, valuation assumptions, thesis and risks supporting it."
    ],
    "correct": 2,
    "explanation": "The 2027 curriculum explicitly covers the elements of detailed company research reports. A recommendation without transparent assumptions, valuation logic and risks cannot be effectively evaluated or challenged by the reader.",
    "source": "https://www.cfainstitute.org/sites/default/files/curriculum-update-2027.pdf"
  },
  {
    "id": "q393",
    "subject": "Equity",
    "topic": "Equity Analyst Research Reports",
    "subtopic": "Sell-side vs buy-side",
    "difficulty": "EXTREME",
    "stem": "A sell-side analyst publishes a 12-month target price and broad client-facing report. A buy-side analyst at a concentrated fund reaches a lower value using the same DCF framework because she assumes weaker pricing and higher reinvestment. Which statement is most appropriate?",
    "options": [
      "One analyst must have used the wrong DCF formula because the framework is identical.",
      "Different conclusions can arise legitimately from different revenue, profitability, investment and financing assumptions even when the modeling framework is the same.",
      "Sell-side and buy-side analysts are required to reach the same value when using the same company filings."
    ],
    "correct": 1,
    "explanation": "A valuation framework does not determine its inputs. The 2027 curriculum emphasizes how differing assumptions can produce different values and compares sell-side and buy-side research contexts. The disagreement should be traced to assumptions, not presumed to be a formula error.",
    "source": "https://www.cfainstitute.org/sites/default/files/curriculum-update-2027.pdf"
  },
  {
    "id": "q394",
    "subject": "Equity",
    "topic": "Equity Analyst Research Reports",
    "subtopic": "Activist short research",
    "difficulty": "EXTREME",
    "stem": "An activist short seller publishes a detailed report alleging accounting problems while holding a short position. An analyst reviewing the report should most appropriately:",
    "options": [
      "accept the claims as more credible because the short seller risks capital.",
      "treat the short position as an incentive/conflict to consider, but evaluate the evidence independently rather than dismiss or accept the claims solely because of the position.",
      "dismiss the report automatically because a short seller cannot produce useful research."
    ],
    "correct": 1,
    "explanation": "Economic incentives matter to source evaluation, but they do not determine factual accuracy. The appropriate response is evidence-based verification of claims, assumptions and source quality. The 2027 curriculum includes activist short sellers within equity research-report analysis.",
    "source": "https://www.cfainstitute.org/sites/default/files/curriculum-update-2027.pdf"
  },
  {
    "id": "q395",
    "subject": "Equity",
    "topic": "The Capital Asset Pricing Model, Market Model, and Other Factor-Based Equity Models",
    "subtopic": "CAPM required return with irrelevant firm-specific risk",
    "difficulty": "EXTREME",
    "stem": "The risk-free rate is 4% and the expected market return is 9%. A stock’s beta is 1.3. The company also faces a binary lawsuit that greatly increases firm-specific return volatility, but the analyst believes it does not change beta. Under CAPM and assuming diversified investors, the required return is closest to:",
    "options": [
      "10.5%, because CAPM uses 4% + 1.3×(9%−4%); the lawsuit does not mechanically add a separate premium if it is diversifiable and beta is unchanged.",
      "11.7%, because beta should multiply the total expected market return rather than the market risk premium.",
      "9.0%, because firm-specific risk replaces market beta when the lawsuit is material."
    ],
    "correct": 0,
    "explanation": "The market risk premium is 9% − 4% = 5%. CAPM gives 4% + 1.3×5% = 10.5%. The lawsuit can be extremely important to the company’s cash-flow scenarios, but CAPM prices systematic risk through beta rather than adding a one-for-one premium for diversifiable firm-specific volatility. The strongest numerical distractor multiplies beta by the total market return instead of the market risk premium.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q396",
    "subject": "Equity",
    "topic": "The Capital Asset Pricing Model, Market Model, and Other Factor-Based Equity Models",
    "subtopic": "Beta effect on valuation",
    "difficulty": "EXTREME",
    "stem": "Two analysts have identical cash-flow forecasts. Analyst A estimates beta at 0.9; Analyst B estimates 1.4 using the same risk-free rate and market risk premium. Under CAPM, all else equal, B should obtain:",
    "options": [
      "a higher required return and therefore a lower present value.",
      "the same value because beta affects expected return but not discount rates.",
      "a lower required return and therefore a higher present value."
    ],
    "correct": 0,
    "explanation": "CAPM converts higher systematic beta into a higher required return when the market risk premium is positive. Discounting the same equity cash flows at a higher rate lowers present value. Beta estimation therefore matters directly to valuation context.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q397",
    "subject": "Equity",
    "topic": "The Capital Asset Pricing Model, Market Model, and Other Factor-Based Equity Models",
    "subtopic": "Market model versus CAPM",
    "difficulty": "EXTREME",
    "stem": "An analyst estimates a stock's historical market-model regression and obtains an intercept that is materially positive. She then claims the intercept should be added to the CAPM required return because both models use beta. Which response is most accurate?",
    "options": [
      "The intercept must always replace the risk-free rate in CAPM.",
      "The market-model intercept is an empirical return parameter; it is not an automatic extra risk premium in the CAPM required-return equation.",
      "Any positive intercept proves the stock is undervalued and should reduce the required return."
    ],
    "correct": 1,
    "explanation": "The market model describes the statistical relation between a security's return and market return, while CAPM is an equilibrium required-return model using the risk-free rate, beta, and market risk premium. A historical regression intercept is not mechanically added to CAPM. Treating it as a guaranteed alpha or pricing adjustment confuses two related but distinct uses of beta.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q398",
    "subject": "Equity",
    "topic": "The Capital Asset Pricing Model, Market Model, and Other Factor-Based Equity Models",
    "subtopic": "Historical beta relevance",
    "difficulty": "BRUTAL",
    "stem": "A utility sold its regulated network business last year and now earns most revenue from a volatile merchant-power operation. An analyst estimates cost of equity using the company's five-year historical beta without examining the business change. Which critique is strongest?",
    "options": [
      "CAPM does not use company-specific risk information, so any historical beta is equally appropriate.",
      "The historical beta may no longer represent the company's current systematic risk, so its relevance should be reassessed before using it in CAPM.",
      "Beta is a legal characteristic of the share class and cannot change when business mix changes."
    ],
    "correct": 1,
    "explanation": "CAPM requires an estimate of current systematic risk. A major change in operating mix can alter sensitivity to market conditions, making a long historical estimate stale even if it is statistically precise. The issue is not that CAPM rewards diversifiable risk; it is whether the beta input is economically representative of the company being valued now.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q399",
    "subject": "Equity",
    "topic": "The Capital Asset Pricing Model, Market Model, and Other Factor-Based Equity Models",
    "subtopic": "Systematic versus idiosyncratic risk",
    "difficulty": "BRUTAL",
    "stem": "Two stocks have the same estimated beta. Stock A has much higher firm-specific return volatility because it faces a binary patent lawsuit. Under the CAPM framework, which statement is most accurate, assuming investors are well diversified?",
    "options": [
      "The lawsuit volatility does not by itself raise CAPM required return unless it changes the stock's systematic beta; CAPM prices systematic rather than diversifiable risk.",
      "Stock A must have a higher CAPM required return because total volatility is always priced one-for-one.",
      "Stock A must have a lower required return because firm-specific risk is rewarded with a diversification premium."
    ],
    "correct": 0,
    "explanation": "CAPM links required return to systematic market risk measured by beta, not total standalone volatility. A severe company-specific event can matter enormously to valuation cash flows, but if it is diversifiable and does not change beta, it does not mechanically increase the CAPM discount rate. The strongest distractor confuses total risk with priced systematic risk.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  },
  {
    "id": "q400",
    "subject": "Equity",
    "topic": "The Capital Asset Pricing Model, Market Model, and Other Factor-Based Equity Models",
    "subtopic": "Why multifactor models matter",
    "difficulty": "EXTREME",
    "stem": "Two companies have similar market betas, but one is highly exposed to energy-price shocks and the other to a persistent size-related factor. An analyst concludes that CAPM therefore guarantees the two securities have identical risk-adjusted expected returns in every useful model. Which response is strongest?",
    "options": [
      "Multifactor models are used only to forecast accounting earnings and cannot inform equity returns.",
      "CAPM uses a single market factor, while APT and multifactor models can incorporate additional systematic factor exposures that may help explain return differences.",
      "Similar market beta proves all systematic risks are identical by definition."
    ],
    "correct": 1,
    "explanation": "The 2027 Equity curriculum asks candidates to understand APT and the importance of multifactor models. Similar CAPM betas mean similar exposure to the market factor, not necessarily identical exposure to other systematic factors. Multifactor models can therefore provide a richer return-risk description without implying that every observed factor premium is permanent or known with certainty.",
    "source": "https://www.cfainstitute.org/sites/default/files/2027levelitopicoutline_online.pdf"
  }
];
